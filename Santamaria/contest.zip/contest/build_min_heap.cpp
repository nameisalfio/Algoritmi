#include<iostream>
#include <fstream>
#include <typeinfo>
#include <cstring>
using namespace std;
void swap(int& a,int& b){
    int tmp=b;
    b=a;
    a=tmp;
}
class MaxHeap{
    public:
        int *array;
        int size;
        int len;
        int heapsize;
        int left(int i){return i<<1;}
        int right(int i){return i<<1|1;}
        int parent(int i){return i>>1;}
        MaxHeap(int size){
            array=new int[size+1];
            this->size=size+1;
            heapsize=1;
        }
        void heapfy(int i){
            int max=i;
            int r=right(i);
            int l=left(i);
            if(l<=heapsize && array[max]<array[l])
                max=l;                
            if(r<=heapsize && array[max]<array[r])
                max=r;
            if(i!=max){
                swap(array[i],array[max]);
                heapfy(max);
            }
        }
        void build_heap(int n){
            heapsize=n;
            for(int i=heapsize/2;i>0;i--){
                heapfy(i);
            }
        }
        int extract_max(){
            swap(array[1],array[heapsize]);
            heapsize--;
            heapfy(1);
            return array[heapsize+1];
        }
};
int riempimento(int len,int dim,ifstream& input){
        MaxHeap* heap=new MaxHeap(len);
        int elem;
        int somma=0;
        for(int i=1;i<=len;i++){
            input>>elem;
            heap->array[i]=elem;
        }
        heap->build_heap(len);
        for(int i=0;i<dim;i++){
            somma+=heap->extract_max();
        }
        return somma;
}
int main(){
    ifstream input;
    ofstream output;
    input.open("input.txt");
    output.open("output.txt");
    int len;
    int dim;
    int val;
    int somma;
    for(int i=0;i<3;i++){
        input>>len;
        input>>dim;
        output<<riempimento(len, dim,input);
        output<<endl;
    }
}