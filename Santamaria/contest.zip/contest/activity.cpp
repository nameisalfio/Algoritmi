#include<iostream>
#include <cstring>
#include <fstream>
#include <sstream>
using namespace std;

class Activity{
    public:
        int s;
        int f;
        Activity(int s,int f){
            this->f=f;
            this->s=s;
        }
        void set (int s,int f){
            this->f=f;
            this->s=s;
        }
};
void swap(Activity* a ,Activity* b){
    Activity* tmp;
    tmp=new Activity(b->s,b->f);
    b->set(a->s,a->f);
    a->set(tmp->s,tmp->f);
}
void sort(Activity** a,int n){
    for(int i=0;i<n-1;i++){
        for(int j=i+1;j<n;j++){
            if(a[j]->f<a[i]->f)    swap(a[i],a[j]);
            else if (a[j]->f==a[i]->f && a[j]->s>a[i]->s) swap(a[i],a[j]);
        }
    }
}
int last_cons(Activity** a,int i){
    for(int j=i-1;j>=0;j--){
        if(a[j]->f<=a[i]->s) return j;
    }
return -1;
}
void insert(ifstream& input ,Activity** a,int n) {
    int e=0,el=0;
    char c;
    for(int i=0;i<n;i++){
        input>>c;
        input>>e;
        input>>c;
        input>>el;
        input>>c;
        a[i]=new Activity(e,el);
    } 
}
void selector(Activity** a,int n, ofstream& output){
    sort(a,n);
    int tempo_impiegato[n];
    tempo_impiegato[0]=a[0]->f-a[0]->s;
    int tempo=0;
    int l=0;
    for(int i=1;i<n;i++){
        tempo=(a[i]->f)-(a[i]->s);
        l=last_cons(a,i);
        if(l!=-1) tempo+=tempo_impiegato[l];
        if(tempo>tempo_impiegato[i-1]) tempo_impiegato[i]=tempo;
        else tempo_impiegato[i]=tempo_impiegato[i-1];
    }
    output<<tempo_impiegato[n-1]<<endl;
}
int main(){
    ifstream input;ofstream output;
    int n;
    input.open("input.txt");
    output.open("output.txt");
    int e=0,el=0;
    char c;
    for(int i=0;i<100;i++){
        input>>n;
        Activity **a;
        a=new Activity* [n];
        for(int i=0;i<n;i++){
            input>>c;
            input>>e;
            input>>c;
            input>>el;
            input>>c;
            a[i]=new Activity(e,el);
        }
        selector(a,n,output);
    }
}
