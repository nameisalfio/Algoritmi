#include <iostream>
#include <cstring>
#include <fstream>
#include <typeinfo>
#include <sstream>
using namespace std;
void swap(int& a,int& b){
    int tmp=b;
    b=a;
    a=tmp;
}
template<class H> class MaxHeap{
    public :
        int heapsize;
        int size;
        H* array;
        int count_heapfy;
        MaxHeap(int len){
            size=len+1;
            heapsize=0;
            array=new H [size];
        }
        int right(int i){return (i<<1)|1;}
        int left(int i){return i<<1;}
        int parent(int i){return i>>1;}
        void insert(H val){
            heapsize++;
            array[heapsize]=val;
            int i=heapsize;
            while (i>1 && array[i]>array[parent(i)]){
                swap(array[i],array[parent(i)]);
                i=parent(i);
            }
            
        }
        void heapfy(int i){
            int r=right(i);
            int l=left(i);
            int max=i;
            if(l<=heapsize && array[l]>array[max]) max=l;
            if(r<=heapsize && array[r]>array[max]) max=r;
            if(i!=max){
                swap(array[max],array[i]);
                heapfy(max);
            }
            if(heapsize>=1){count_heapfy++ ;}
        }
        H extract(){
            swap(array[1],array[heapsize]);
            heapsize-- ;
            heapfy(1);
            return array[heapsize+1];
        }
        void stampa(ofstream& output){
            for(int i=1;i<=heapsize;i++){
                output<<array[i]<<'\t';
            }
            output<<endl;
        }
};
template <class H> void parsing(ifstream& input, ofstream& output){
    int n;
    input>>n;
    H x;
    char s;
    string b;
    MaxHeap <H>* heap=new MaxHeap <H> (n);
    for(int i=0;i<n;i++){
        input>>s;
        input>>s;
        if(s=='x'){
            input>>b; 
            x=heap->extract();
        }
        else {
            input>>x;
            heap->insert(x);
        }
    }
     output<<heap->count_heapfy<<'\t';
        heap->stampa(output);
}
int main(){
    ifstream input;
    ofstream output;
    input.open("input.txt");
    output.open("output.txt");
    string tipo;
    for(int i=0;i<100;i++){
        input>>tipo;
        switch (tipo[0])
        {
        case 'i':
            parsing<int>(input,output);
            break;
        case 'b':
            parsing<bool>(input,output);
            break;
        case 'c':
            parsing<char>(input,output);
            break;
        case 'd':
            parsing<double>(input,output);
            break;
        default:
            break;
        }
    }
}