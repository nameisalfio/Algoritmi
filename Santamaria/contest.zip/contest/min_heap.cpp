#include<iostream>
#include <cstring>
#include <fstream>
#include<typeinfo>

using namespace std;
void swap(int& a,int& b) {
    int tmp=b;
    b=a;
    a=tmp;
}
template<class H> class MinHeap{
    public:
        H* array;
        int size;
        int heapsize;
        int count_heapfy;
        MinHeap(int len){
            array=new H[len+1];
            size=len+1;
            heapsize=0;
            count_heapfy=0;
        }
        int right(int i){return i<<1|1;}
        int left(int i){return i<<1;}
        int parent(int i){return i>>1;}
        void insert(H val){
            heapsize++;
            array[heapsize]=val;
            int i=heapsize;
            while(i>1 && array[i]<array[parent(i)]){
                swap(array[i],array[parent(i)]);
                i=parent(i);
            }
        }
        void heapfy(int i){
            int r=right(i);
            int l=left(i);
            int min=i;
            if(l<=heapsize && array[min]>array[l]) min=l;
            if(r<=heapsize && array[min]>array[r]) min=r;
            if(i!=min){
                swap(array[i],array[min]);
                heapfy(min);
            }
            if(heapsize>=1) count_heapfy++;
        }
        void extract(){
            swap(array[1],array[heapsize]);
            heapsize--;
            heapfy(1);
        }
        void stampa(ofstream& output){
            output<<count_heapfy<<'\t';
            for(int i=1;i<=heapsize;i++){
                output<<array[i]<<'\t';
            }
            output<<endl;
        }
        
};
template<class H> void parsing(ifstream& input,ofstream& output){
    int n;
    char s;
    string c;
    input>>n;
    MinHeap<H>* heap= new MinHeap<H>(n);
    H elem;
    for(int i=0;i<n;i++){
        input>>s;
        input>>s;
        if(s==':'){
            input>>elem;
            heap->insert(elem);
        }
        else{
            input>>c;
            heap->extract();
        }
    }
    heap->stampa(output);
}
int main(){
    ifstream input;
    ofstream output;
    input.open("inputmho.txt");
    output.open("outputminho.txt");
    string tipo;
    for(int i=0;i<3;i++){
        input>>tipo;
        switch (tipo[0])
        {
        case 'i':
            parsing<int>(input,output);
            break;
        case 'd':
            parsing<double>(input,output);
            break;
        case 'c':
            parsing<char>(input,output);
            break;
        case 'b':
            parsing<bool>(input,output);
            break;
        
        default:
            break;
        }
    }
}

