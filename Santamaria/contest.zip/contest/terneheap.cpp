#include<iostream>
#include <cstring>
#include <fstream>
#include <sstream>
#include <typeinfo>

using namespace std;
template<class H> class Terna{
    private :
        H val;
        H val1;
        H val2;
    public:
        Terna(H val,H val1,H val2){
            this->val1=val1;
            this->val2=val2;
            this->val=val;
        }
        void set(H val,H val1,H val2){
            this->val1=val1;
            this->val2=val2;
            this->val=val;
        }
        friend bool operator >(Terna<H>&  a,Terna<H>& b){
            if(a.val>b.val) return 1;
            else if(a.val==b.val && a.val1>b.val1) return 1;
            else if(a.val==b.val && a.val1==b.val1 && a.val2>b.val2) return 1;
            return 0;
        }
        H getval(){
            return val;
        }
        H getval2(){return val1;}
        H getval3(){return val2;}
};
template<class H> void swap(Terna<H>& a,Terna<H>& b ){
    Terna<H> * tmp=new Terna<H> (b.getval(),b.getval2(),b.getval3());
    b.set(a.getval(),a.getval2(),a.getval3());
    a.set(tmp->getval(),tmp->getval2(),tmp->getval3());
}
template <class H> class MaxHeap{
    public:
        Terna<H>** array;
        int size;
        int heapsize;
        int count_heapify;
        MaxHeap(int len){
            size=len+1;
            array=new Terna<H>* [size];
            heapsize=0;
            count_heapify=0;
        }
        int left(int i){return i<<1;}
        int right(int i){return (i<<1)|1;}
        int parent(int i){return i>>1;}
        void heapify(int i){
            int r=right(i);
            int l=left(i);
            int max=i;
            if(l<=heapsize && *array[l]>*array[max]) max=l;
            if(r<=heapsize && *array[r]>*array[max]) max=r;
            if(i!=max){
                swap(array[i],array[max]);
                heapify(max);
            }
            if(heapsize>=1) count_heapify++;
        }
        void insert(ifstream& input,int n){
            H elem;H elem1;H elem2 ;char c;
            for(int i=1;i<=n;i++){
                input>>c;
                input>>elem;
                input>>elem1;
                input>>elem2;
                input>>c;
               //cout<<elem<<'\t'<<elem1<<'\t'<<elem2;
                array[i]=new Terna<H>(elem,elem1,elem2);
            }
        }
        void build(int n) {
            heapsize=n;
            for(int i=heapsize/2;i>=1;i--)
                heapify(i);
        }
        void extract(){
            swap(array[1],array[heapsize]);
            heapsize--;
            heapify(1);
        }
        void Heapsort(){
            for(int i=0;i<size-1;i++)
                extract();
        }
        void stampa(ofstream& output){
            for(int i=1;i<size;i++) 
                output<<"("<<array[i]->getval()<<" "<<array[i]->getval2()<<" "<<array[i]->getval3()<<")"<<" ";
            output<<endl;
        }
};
template<class H> void parsing(ifstream& input ,ofstream& output){
    int n;
    input>>n;
    MaxHeap<H>* heap=new MaxHeap<H> (n);
    heap->insert(input,n);
    
    heap->build(n);
    heap->Heapsort();
    output<<heap->count_heapify<<" ";
    heap->stampa(output);
}
int main(){
    ifstream input;
    ofstream output;
    input.open("input.txt");
    output.open("output.txt");
    string tipo;
    for(int i=0;i<100;i++){
        input>>tipo;
        cout<<tipo<<'\t';
        switch (tipo[0])
        {
        case 'i':
            parsing<int>(input,output);
            break;
        case 'b':
            parsing<bool>(input,output);
            break;
        case 'd':
            parsing<double>(input,output);
            break;
        case 'c':
            parsing<char>(input,output);
            break;
        default:
            break;
        }
        
    }
    return 0;
}
