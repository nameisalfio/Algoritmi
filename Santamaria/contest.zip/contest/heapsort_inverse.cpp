#include <iostream>
#include <cstring>
#include <fstream>
#include <typeinfo>
using namespace std;
void swap(int& a,int& b){
    int tmp=b;
    b=a;
    a=tmp;
}
template<class H>class MinHeap{
    public:
        H* array;
        int size;
        int heapsize;
        int cout_heapfiy;
        MinHeap(int len){
            array=new H[len+1];
            size=len+1;
            heapsize=0;
            cout_heapfiy=0;
        }
        int left(int i){return i<<1;}
        int right(int i){return i<<1|1;}
        int parent(int i){return i>>1;}
        void insert(H elem){
            heapsize++;
            array[heapsize]=elem;
        }
        void heapfy(int i){
            int l=left(i);
            int r=right(i);
            int min=i;
            if(l<=heapsize && array[l]<array[min]) min=l;
            if(r<=heapsize && array[r]<array[min]) min=r;
            if(i!=min){
                swap(array[i],array[min]);
                heapfy(min);
            }
            if(heapsize>=1) cout_heapfiy++;
        }
        void build(){
            for(int i=heapsize/2;i>0;i--)
                heapfy(i);
        }
        H extract(){
            swap(array[1],array[heapsize]);
            heapsize--;
            heapfy(1);
            return array[heapsize+1];
        }
        void heapsort(ofstream& output){
            build();
            H* a;
            a=new H[heapsize];
            int n=heapsize;
            for(int i=n-1;i>=0;i--){
                a[i]=extract();
                cout<<a[i]<<endl;
            }
            output<<cout_heapfiy<<'\t';
            for(int i=0;i<n;i++){
                output<<a[i]<<'\t';
            }
            output<<endl;
        }

};
template<class H> void parsing(ifstream& input,ofstream& output){
    int n;
    H elem;
    input>>n;
    MinHeap<H>* heap=new MinHeap<H> (n);
    cout<<n<<endl;
    for(int i=0;i<n;i++){
        input>>elem;
        heap->insert(elem);
    }
    heap->heapsort(output);

}
int main(){
    ifstream input;
    ofstream output;
    input.open("inputheapsort_inverse.txt");
    output.open("outputheapsort_inverse.txt");
    string s;
    for(int i=0;i<3;i++){
        input>>s;
       switch(s[0]){
            case 'i':
                parsing<int>(input,output);
                break;
        case 'b':
                parsing<bool>(input,output);
                break;
        case 'c':
                parsing<char>(input,output);
                break;
        case 'd':
                parsing<double>(input,output);
                break;
        default:
                break;
        }
    }

}