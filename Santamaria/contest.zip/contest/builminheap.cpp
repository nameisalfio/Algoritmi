#include <iostream>
#include <cstring>
#include <fstream>
#include <sstream>
using namespace std;
void swap(int& a,int & b){
    int tmp=b;
    b=a;
    a=tmp;
}
template <class H> class MinHeap{
    public :
        int heapsize;
        int size;
        H* array;
        MinHeap(int len){
            size=len+1;
            heapsize=0;
            array=new H [size];
        }
        int left(int i){return i<<1;}
        int right(int i){return (i<<1)|1;}
        int parent(int i){return i>>1;}
        void heapfy(int i){
            int r =right(i);
            int l=left(i);
            int min=i;
            if(l<=heapsize && array[l]<array[min]) min=l;
            if(r<=heapsize && array[r]<array[min]) min=r;
            if(i!=min){
                swap(array[i],array[min]);
                heapfy(min);
            }
        }
        void build(int n){
            heapsize =n;
            for(int i=heapsize/2;i>=1;i--) heapfy(i);
        }
        void insert(int n,ifstream& input) {
            H elem;
            for(int i=1;i<=n;i++){
                input>>elem;
                array[i]=elem;
            }
        }
        void stampa(int n,ofstream& output){
            for(int i=1;i<=n;i++)  output<<array[i]<<'\t';
        }
};
template <class H> void parsing(ifstream& input ,ofstream& output){
    int n;
    input>>n;
    MinHeap<H>* heap=new MinHeap<H> (n);
    heap->insert(n,input );
    heap->build(n);
    heap->stampa(n,output);
}
int main(){
    ifstream input;
    ofstream output;
    input.open("iminheap.txt");
    output.open("ominheap.txt");
    string tipo;
    for(int i=0;i<100;i++){
        input>>tipo;
        switch (tipo[0])
        {
        case 'i':
            parsing<int>(input,output);
            break;
        case 'd':
            parsing<double>(input,output);
            break;
        case 'b':
            parsing<bool>(input,output);
            break;
        case 'c':
            parsing<char>(input,output);
            break; 
                    
        default:
            break;
        }
        output<<endl;
    }
    return 0;
