#include <iostream>
#include <cstring>
#include <fstream>
#include <sstream>
#include <typeinfo>
using namespace std;
template<class H> class Coppia{
    public:
        H val;
        H val1;
        Coppia(H val,H val1){
            this->val1=val1;
            this->val=val;
        }
        void set(H val ,H val1){
            this->val=val;
            this->val1=val1;
        }
        H get1(){
            return val;
        }
        H get2(){
            return val1;
        }
        bool friend operator >(Coppia<H>& a ,Coppia<H>& b ){
            if(a.val>b.val)return 1;
            else if(a.val==b.val && a.val1>b.val1) return 1;
            return 0;
        }
        
};
template<class H> void swap(Coppia<H>& a,Coppia<H>& b){
    Coppia <H>*  tmp=new Coppia<H> (b.get1(),b.get2());
    b.set(a.get1(),a.get2());
    a.set(tmp->get1(),tmp->get2());
}
template<class H> class MaxHeap{
    public:
        Coppia<H> ** array;
        int size;
        int heapsize;
        int countheapify;
        MaxHeap(int len){
            size=len+1;
            heapsize=0;
            countheapify=0;
            array=new Coppia <H>* [size];
        }
        int left(int i){return i<<1;}
        int right(int i){return (i<<1)|1;}
        int parent(int i){return i>>1;}
        void heapify(int i){
            int r=right(i);
            int l=left(i);
            int max=i;
            if(l<=heapsize && *array[l]>*array[max]) max=l;
            if(r<=heapsize && *array[r]>*array[max]) max=r;
            if(i!=max){
                swap(array[i],array[max]);
                heapify(max);
            }
            if(heapsize>=1)countheapify++;
        }
        void build(int n){
            heapsize=n;
            for(int i=heapsize/2;i>=1;i--)
                heapify(i);
        }
        void insert(int n,ifstream& input){
            H elem;H elem1;char c;
            for(int i=1;i<=n;i++){
                input>>c;
                input>>elem;
               // input>>c;
                input>>elem1;
                input>>c; 
                array[i]=new Coppia<H>(elem,elem1);
            }
        }
        void extract(){
            swap(array[1],array[heapsize]);
            heapsize--;
            heapify(1);
        }
        void heapsort(){
            for(int i=1;i<size;i++){extract ();}
        }
        void stampa(ofstream& output){
            for(int i=1;i<size;i++){
                output<<"("<<array[i]->get1()<<'\t'<<array[i]->get2()<<")"<<'\t';
            }
            output<<endl;
        }
};
template <class H> void parsing(ifstream& input,ofstream& output){
    int n;
    input>>n;
    MaxHeap<H>* heap=new MaxHeap<H> (n);
    heap->insert(n,input);
    heap->build(n);
    heap->heapsort();
    output<<heap->countheapify<<'\t';
    heap->stampa(output);
}
int main(){
    ifstream input;
    ofstream output;
    input.open("input.txt");
    output.open("output.txt");
    string tipo;
    for(int i=0;i<100;i++){
        input>>tipo;
        switch (tipo[0])
        {
        case 'i':
            parsing<int>(input,output);
            break;
        case 'b':
            parsing<bool>(input,output);
            break;
        case 'c':
            parsing<char>(input,output);
            break;
        case 'd':
            parsing<double >(input,output);
            break;
        default:
            break;
        }
    }
    output.close();

}