#include<iostream>
#include<fstream>

#define inf 100

using namespace std;

class Edge{
	private:
		int u,v,w;
	public:
		Edge(int u1, int v1, int w1){
			u = u1;
			v = v1;
			w = w1;
		}
		int getU(){
			return u;
		}
		int getV(){
			return v;
		}
		int getPeso(){
			return w;
		}
};

template<class T> class Graph{
	private:
		int m,n;
		int len;
		T* etichette;
		Edge** e;
		int findIndex(T x){
			for(int i = 0; i < n; i++){
				if(etichette[i] == x)return i;
			}
			return -1;
		}
	public:
		Graph(){
			len = 1000;
			m = 0;
			n = 0;
			etichette = new T[len];
			e = new Edge*[len];
			for(int i = 0; i < len; i++) e[i] = NULL;
		}
		
		void addNode(T x){
			etichette[n] = x;
			n++;
			//cout<<"Nodo aggiunto "<<x<<endl;
		}
		
		void addEdge(T u, T v, int w){
			e[m] = new Edge(u,v,w);
			m++;
			//cout<<"Edge aggiunto "<<u<<" "<<v<<" "<<w<<endl;
		}
		
		void bellmanFord(T sorgente, T destinazione, ofstream &out, int k){
			int s = findIndex(sorgente);
			int f = findIndex(destinazione);
			int d[n];
			for(int i = 0; i < n; i++) d[i] = inf;
			d[s] = 0;
			//cout<<"valore 1 "<<d[f]<<endl;
			for(int i = 0; i < k; i++){
				for(int j = 0; j < m; j++){
					//relax
					int u = e[j]->getU();
					int v = e[j]->getV();
					int w = e[j]->getPeso();
					//cout<<"relax ("<<u<<","<<v<<","<<w<<")"<<endl;
					if(d[v] > d[u] + w) d[v] = d[u] + w;
				}
			}
			//cout<<"valore "<<d[f]<<endl;
			if(d[f] == inf){
				out <<"inf."<<endl;
			}else{
				out << d[f] << endl;
			}
		}
};

int main(){
	ifstream in("input.txt");
	ofstream out("output.txt");
	int n,m,k;
	for(int i = 0; i < 100; i++){
		in >> n;
		in >> m;
		in >> k;
		Graph<int> grafo;
		for(int j = 0; j < n; j++){
			grafo.addNode(j);
		}
		
		for(int j = 0; j < m; j++){
			int u,v,w;
			char tmp;
			
			in>>tmp;
			in>>u;
			in>>v;
			in>>w;
			in>>tmp;
			
			grafo.addEdge(u,v,w);
		}
		int s,f;
		in>>s;
		in>>f;
		grafo.bellmanFord(s,f,out,k);
	}
}
