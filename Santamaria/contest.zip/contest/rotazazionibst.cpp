#include <iostream>
#include <fstream>
#include <cstring>
#include <cctype>
using namespace std;
template <class H> struct Nodo{
    H  valore;
    Nodo<H>* padre;
    Nodo<H>* sinistro;
    Nodo<H>* destro;
};
template<class H> class albero{
    public: 
        Nodo<H>* root;
        albero() {root=NULL;}
        void insert(H val){
            Nodo<H>* nuovo=new Nodo<H>;
            nuovo->valore=val;
            nuovo->destro=nuovo->sinistro=NULL;
            Nodo<H>* x=NULL;
            Nodo<H>* y=root;
            while(y!=NULL){
                x=y;
                if(val>y->valore) y=y->destro;
                else y=y->sinistro;
            }   
            nuovo->padre=x;
            if(x==NULL){ root =nuovo;}
            else if(val<=x->valore) x->sinistro=nuovo;
            else x->destro=nuovo;
        }
        void trapianta(Nodo<H>* u,Nodo<H>* v){
            if(u->padre==NULL)root=v;
            else if(u==u->padre->sinistro) u->padre->sinistro=v;
            else u->padre->destro=v;
        }
        Nodo<H>* search(H val){
            Nodo<H>* p=root;
            while(p!=NULL && p->valore!=val){
                if(p->valore<val) p=p->destro;
                else p=p->sinistro
            }
            return p;
        }
        Nodo<H>* min(Nodo<H>* p){
            while(p->sinistro!=NULL){
                p=p->sinistro;
            }
            return p;
        }
        void cancella(H val){
            Nodo<H>* x=search(val);
            if(x!=NULL){
                Nodo<H>* y;
                if(x->destro==NULL) trapianta(x,x->destro);
                else if(x->sinistro==NULL) trapianta(x,x->sinistro);
                else{
                    y=min(x->destro);
                    if(y->padre!=x){
                        trapianta(y,y->destro);
                        y->destro=x->destro;
                        y->destro->padre=y;
                    }
                    trapianta(y,y->sinistro);
                    y->sinistro=x->sinistro;
                    x->sinistro->padre=y;
                } 
                delete x;
            }
        }
        void inorder(Nodo<H>* p,ofstream& output){
            if(p!=NULL){
                inorder(p->sinistro,output);
                output<<p->valore<<'\t';
                inorder(p->destro,output);
            }
        }
        void s_inorder(ofstream& output){
            Nodo<H>* p=root;
            inorder(p,output);
        }
        void left_rotate(Nodo<H>* p){
            Nodo<H>* y=p->destro;
            Nodo<H>* z=p->padre;
            if(r!=NULL){
                p->destro=y->sinistro;
                y->sinistro=p;
                trapianta(p,y);
                y->padre=z;
                p->padre=y;
                if(p->destro!=NULL) p->destro->padre=p;

            }
            
        }
        void right_rotate(Nodo<H>* p){
            Nodo<H>* y=p->sinistro;
            Nodo<H>* z=p->padre;
            if(y!=NULL){
                p->destro=y->sinistro;
                y->destro=p;
                trapianta(p,y);
                y->padre=z;
                p->padre=y;
                if(p->sinistro!=NULL) p->sinistro->padre=p;
            }
        }
};
int main(){
    return 0;
}