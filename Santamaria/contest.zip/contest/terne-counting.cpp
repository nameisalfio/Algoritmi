#include<iostream>
#include <cstring>
#include <sstream>
#include <fstream>
using namespace std;
class Terna{
    public: 
        double val1;
        double val2;
        double val3;
        Terna(double val1,double val2,double val3){
            this->val1=val1;
            this->val2=val2;
            this->val3=val3;
        }
        friend bool operator >(Terna a,Terna b){
            if(a.val1>b.val1) return 1;
            else if(a.val1==b.val1 && a.val2>b.val2)  return 1;
            else if(a.val1==b.val1 && a.val2==b.val2 && a.val3>b.val3) return 1;
            return 0; 
        }
        void set(double val1,double val2,double val3){
            this->val1=val1;
            this->val2=val2;
            this->val3=val3;
        }
        double getval1(){
            return val1;
        }
         double getval2(){
            return val2;
        }
         double getval3(){
            return val3;
        }

};
void swap(Terna a,Terna b){
    Terna* tmp=new Terna(b.val1,b.val2,b.val3);
    b.set(a.val1,a.val2,a.val3);
    a.set(tmp->val1,tmp->val2,tmp->val3);
}
void stampa(int* a,int n,ofstream& output){
    for(int i=0;i<n;i++)
        output<<a[i]<<" ";
}
void stampaT(Terna** a,int n,ofstream& output){
    for(int i=0;i<n;i++){
        output<<" ("<<a[i]->getval1()<<",";
        output<<a[i]->getval2()<<","<<a[i]->getval3()<<") ";
    }
    output<<endl;
}
int mini(int* a,int n){
    int min=a[0];
    for(int i=1;i<n;i++){
        if(min>a[i])
            min=a[i];
    }
    return min;
}
int maxm(int* a,int n){
    int max=a[0];
    for(int i=1;i<n;i++){
        if(max<a[i])
            max=a[i];
    }
    return max;
}
Terna** counting_sort(Terna** a,int n,ofstream& output){
    int *A;
    double *r=new double[n];
    double *t=new double [n];
    A=new int [n];
    for(int i=0;i-n;i++){
        A[i]=a[i]->val1*10;
        cout<<A[i]<<"  ";
        r[i]=a[i]->val2;
        t[i]=a[i]->val3;
    }
    cout<<endl;
    int min=mini(A,n);
    int max=maxm(A,n);
    cout<<max<<"   "<<min<<endl;
    int range=max-min+1;
    cout<<range<<endl;
    int *c=new int[range];
    for(int i=0;i<range;i++) c[i]=0;
    for(int i=0;i<n;i++) c[A[i]-min]++;
    for(int i=1;i<range;i++) c[i]+=c[i-1];
    Terna** b=new Terna* [n];
    for(int i=n-1;i>=0;i--){
        b[c[A[i]-min]-1]=new Terna (A[i]/10.0,r[i],t[i]);
        c[A[i]-min]--;
    }
    /*for(int i=1;i<n;i++){
        if(*b[i-1]>*b[i])
            swap(b[i],b[i-1]);
    }*/
    stampa(c,range,output);
    delete[] c;
    return b;
}
int main(){
    ifstream input;
    ofstream output;
    input.open("input.txt");
    output.open("output.txt");
    int n;
    char c;
    double val1,val2,val3;
    for(int i=0;i<100;i++){
        input>>n;
        Terna **a;
        a=new Terna* [n];
        for(int i=0;i<n;i++){
            input>>c;
            input>>val1;
            //input>>c;
            input>>val2;
            //input>>c;
            input>>val3;
            input>>c;
            a[i]=new Terna(val1,val2,val3);
        }
        Terna** result;
        result=counting_sort(a,n,output);
        stampaT(result,n,output);
    }
}
