#include <iostream>
#include <cstring>
#include <fstream>
#include <sstream>
using namespace std;
int mini(int a,int b,int c){
    int min=a;
    if(b<min)min=b;
    if(min>c) min=c;
    return min;
}
int edit(string a,string b){
    int** M;
    M=new int*[a.length()];
    for(int i=0;i<a.length();i++){
        M[i]=new int [b.length()];
    }
    for(int i=0;i<a.length();i++){
        for(int j=0;j<b.length();j++){
            if(i==0)M[i][j]=j;
            else if(j==0)M[i][j]=i;
           else M[i][j]=0;
          // cout<<M[i][j]<<'\t';
        }
      //  cout<<endl;
    }
    for(int i=1;i<a.length();i++){
        for(int j=1;j<b.length();j++){
            if(a[i]==b[j]) M[i][j]=M[i-1][j-1];
            else if(a[i]!=b[j]) M[i][j]=mini(M[i-1][j-1],
                                            M[i-1][j],
                                            M[i][j-1])
                                            +1;
        }
    }
    return M[a.length()-1][b.length()-1];
}
int main(){
    int n;
    string a,b;
    ifstream input;
    ofstream output;
    input.open("ilcs.txt");
    output.open("oedit.txt");
    for(int i=0;i<3;i++){
        input>>n;
        input>>n;
        input>>a;
        input>>b;
        a="0"+a;
        b="0"+b;
        output<<edit(a,b)<<endl;
    }
}