#include<fstream>
#include<iostream>

#define inf 101

using namespace std;

class Edge{
	private:
		int u,v,w;
	public:
		Edge(int u1,int v1, int w1){
			u = u1;
			v = v1;
			w = w1;
		}
		int getU(){
			return u;
		}
		int getV(){
			return v;
		}
		int getPeso(){
			return w;
		}
};

template<class T> class Graph{
	private:
		Edge** e;
		T* etichette;
		int n,m;
		int len;
		int findIndex(T x){
			for(int i = 0; i < n; i++) if(etichette[i] == x) return i;
			return -1;
		}
	public:
		Graph(){
			len = 1000;
			e = new Edge*[len];
			for(int i = 0; i < len; i++) e[i] = NULL;
			etichette = new T[len];
			n = 0;
			m = 0;
		}
		
		~Graph(){
			delete[]etichette;
			for(int i = 0; i < len; i++) delete e[i];
			delete[]e;
		}
		
		void addNode(T x){
			if(n == len) return;
			
			etichette[n] = x;
			n++;
			
			//cout<<"Nodo "<<x<<" aggiunto"<<endl;
		}
		
		void addEdge(T u, T v, int w){
			int i = findIndex(u);
			int j = findIndex(v);
			if(j < 0 | i < 0) return;
			e[m] = new Edge(i,j,w);
			m++;
			
			//cout<<"Edge("<<u<<" "<<v<<" "<<w<<" aggiunto\n";
		}
		
		void bellmanFord(T s,T des, ofstream &out){
			int d[n];
			
			int sorgente = findIndex(s);
			int destinazione = findIndex(des);
			for(int i = 0; i < n; i++) d[i] = inf; //initializeS
			
			d[sorgente] = 0;
			
			for(int i = 1; i < n; i++){
				for(int j = 0; j < m; j++){
					//relax
					int u = e[j]->getU();
					int v = e[j]->getV();
					int w = e[j]->getPeso();
					if(d[v] > d[u] + w) d[v] = d[u] + w;
				}
			}
			
			//test cicli negativi
			for(int j = 0; j < m; j++){
					//relax
					int u = e[j]->getU();
					int v = e[j]->getV();
					int w = e[j]->getPeso();
					if(d[v] > d[u] + w){
						out << "undef."<<endl;
						return;
					}
			}
			if(d[destinazione] == inf){
				out << "inf."<<endl;
			}else{
				out << d[destinazione]<<endl;
			}
			//cout<<"Eseguito"<<endl;
			return;
		}
};

int main(){
	string tipo;
	string buffer;
	int n,m;
	ifstream in("input.txt");
	ofstream out("output.txt");
	
	for(int i = 0; i < 100; i++){
		//cout<<"test"<<endl;
		in >> n >> m;
		in >> tipo;
		if(tipo == "int"){
			Graph<int> grafo = Graph<int>();
			for(int j = 0; j < n; j++){
				int val;
				in >> val;
				grafo.addNode(val);
			}
			for(int j = 0; j < m; j++){
				
				int u,v,w;
				char tmp;
				in >> tmp;
				in >> u;
				in >> v;
				in >> w;
				in >> tmp;
				grafo.addEdge(u,v,w);
			}
			int s,d;
			in >> s >> d;
			//cout<<"letto s "<<s<<" e d "<<d<<endl;
			grafo.bellmanFord(s,d,out);
		}else{
			Graph<double> grafo = Graph<double>();
			for(int j = 0; j < n; j++){
				double val;
				in >> val;
				grafo.addNode(val);
			}
			for(int j = 0; j < m; j++){
				double u,v;
				int w;
				char tmp;
				in >> tmp;
				in >> u;
				in >> v;
				in >> w;
				in >> tmp;
				grafo.addEdge(u,v,w);
			}
			double s,d;
			in >> s >> d;
			grafo.bellmanFord(s,d,out);
		}
		//cout<<"fine corsa"<<endl;
	}
	return 1;
}
