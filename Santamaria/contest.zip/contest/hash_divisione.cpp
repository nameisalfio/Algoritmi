#include<iostream>
#include <fstream>
#include <typeinfo>
#include <cstring>
using namespace std;
template <class H> struct Nodo{
    Nodo<H>* succ;
    H val;
};
template <class H>  class lista{
    public:
        Nodo<H>* testa;
        lista(){
            testa=NULL;
            //testa->succ=NULL;
        }
        void lista_insert(H val){
            Nodo<H>* p=new Nodo<H> ;
            p->val=val;
            p->succ=NULL;
            if(testa==NULL){
                testa=p;
                testa->succ=NULL;
            }    
            else if(testa->succ==NULL){
                testa->succ=p;
                p->succ=NULL;
            }
            else{
                Nodo<H>* a;
                a=testa;
                while(a->succ!=NULL){
                    a=a->succ;
                }
                a->succ=p;
            }

        }
        void stampa(){
            Nodo<H>* p;
            p=testa;
            while(p!=NULL){
                cout<<p->val<<'\t';
                p=p->succ;
            }
        }
};
template <class H> class Hash{
    public:
        lista<H>** array;
        int N;
        int M;
        H key;
        int* count;
        Hash(int M){
            this->M=M;
            count=new int[M];
            array=new lista<H>* [M];
            for(int i=0;i<M;i++){
            array[i]=new lista<H> ();
            }
        }
        void insert(H val){
            array[(int)val%M]->lista_insert(val);
            count[(int)val%M]++;
        }
        void conta_bucket(ofstream& output){
           for(int i=0;i<M;i++){
               output<<count[i]<<'\t';
           }
           output<<endl;
        }

} ;
template <class H> void parsing(ifstream& input,ofstream& output){
    int M;
    input>>M;
    int N;
    input>>N;
    Hash<H>* h=new Hash<H>(M);
    H elem;
    for(int i=0;i<N;i++){
        input>>elem;
        h->insert(elem);
    }
    h->conta_bucket(output);
}
int main(){
    ifstream input;
    ofstream output;
    input.open("inputh.txt");
    output.open("outputh.txt");
    string tipo;
    for(int i=0;i<3;i++){
        input>>tipo;
        switch (tipo[0])
        {
        case 'i':
            parsing<int>(input,output);
            break;
        case 'd':
            parsing<double>(input,output);
            break;
        case 'b':
            parsing<bool>(input,output);
            break;
        case 'c':
            parsing<char>(input,output);
            break;
        
        default:
            break;
        }
    }
}
