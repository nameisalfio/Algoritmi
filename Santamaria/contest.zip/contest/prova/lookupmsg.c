#include <sys/msg.h>
#include <time.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <time.h>
#include <string.h>
#define MAX_LEN 1024

#define CONTINUE 100
#define STOP 101

#define IN_1 100
#define IN_2 101

#define IN 1
#define DB 2
#define OUT 3

//mtype destinatario
typedef struct{
    long mtype;
    char nome[MAX_LEN];
    int processo;           //IN -> DB
    int end;
}in_db_query;

typedef struct{
    long mtype;
    int valore;             //DB -> OUT
    int processo;
    int end;
}db_out_query;

typedef struct{
    char parola[MAX_LEN];   
    char valore[MAX_LEN];
}db_node;


void in(int coda_IN_DB, char* query, int id){
    sleep(1);
    char buffer[MAX_LEN];
    in_db_query msgTo;
    FILE* in;
    in = fopen(query, "r");
    while(fgets(buffer, MAX_LEN, in) != NULL){
        buffer[strcspn(buffer, "\n")]=0;
        msgTo.mtype = DB;
        msgTo.end = CONTINUE;
        msgTo.processo = id;
        strcpy(msgTo.nome, buffer);
        printf("IN: invio richiesta per la query: <%s>\n", buffer);
        if(msgsnd(coda_IN_DB, &msgTo, sizeof(msgTo) - sizeof(long), 0) == -1){         
            perror("IN: errore nell'invio della query\n");
            exit(1);
        } 
    }
    fclose(in);
    msgTo.mtype = DB;
    msgTo.end = STOP;
    msgTo.processo = id;
    if(msgsnd(coda_IN_DB, &msgTo, sizeof(msgTo) - sizeof(long), 0) == -1){         
        perror("IN: errore nell'invio della query di fine\n");
        exit(1);
    } 
    exit(0);
}



void db(int coda_IN_DB, int coda_DB_OUT, char* f){
    in_db_query msgIn;
    db_out_query msgOut;
    char buffer[MAX_LEN];
    int n=0;
    FILE* file;

    file = fopen(f, "r");
    while(fgets(buffer, MAX_LEN, file) != NULL)   n++;
    fclose(file);

    db_node db_list[n];
    int i=0;

    file = fopen(f, "r");
    while(fgets(buffer, MAX_LEN, file) != NULL){
        strcpy(db_list[i].parola, strtok(buffer,":"));
        strcpy(db_list[i].valore, strtok(NULL,"\n")); 
        i++;
    }
    fclose(file);

    printf("CONTENUTO DEL DATABASE\n");
    for(int i=0;i<n;i++)    printf("[%s, %s],", db_list[i].parola, db_list[i].valore);
    printf("\n\n");

    
    int end=0;
    while(1){
        if(msgrcv(coda_IN_DB, &msgIn, sizeof(msgIn) - sizeof(long),DB, 0) == -1){            //mettiamo chi sono io (messaggi che voglio ricevere)
            perror("DB: errore nella ricezione della query\n");
            exit(1);
        }
        if(msgIn.end == STOP)   end++;
        if(end == 2)    break; 
        int flag = 0;
        for(int i=0;i<n;i++){
            if(strcmp(msgIn.nome, db_list[i].parola) == 0){
                flag = 1;
                printf("DB: query <%s> trovata con valore <%s>\n", msgIn.nome, db_list[i].valore);
                msgOut.end = CONTINUE;
                msgOut.mtype = OUT;
                msgOut.processo = msgIn.processo;
                msgOut.valore = atoi(db_list[i].valore);
                if(msgsnd(coda_DB_OUT, &msgOut, sizeof(msgOut) - sizeof(long), 0) == -1){         
                    perror("DB: errore nell'invio del valore a OUT\n");
                    exit(1);
                }   
                break;
            }    
        }

        if(flag == 0)    printf("DB: nessun riscontro nel database per la query: <%s>\n", msgIn.nome);
        
    }
    msgOut.end = STOP;
    msgOut.mtype = OUT;
    if(msgsnd(coda_DB_OUT, &msgOut, sizeof(msgOut) - sizeof(long), 0) == -1){         
        perror("DB: errore nell'invio delvalore a OUT\n");
        exit(1);
    }  
    exit(0);
}

void out(int coda_DB_OUT){
    db_out_query msg;
    int in1=0;
    int in2=0;
    int tot_in1=0;
    int tot_in2=0;
    while(1){
        if(msgrcv(coda_DB_OUT, &msg, sizeof(msg) - sizeof(long),OUT, 0) == -1){            //mettiamo chi sono io (messaggi che voglio ricevere)
            perror("OUT: errore ricezione messaggio da DB\n");
            exit(1);
        }
        
        if(msg.processo == IN_1)    printf("OUT: aggiornamento dei valori di IN_1\n");
        if(msg.processo == IN_2)    printf("OUT: aggiornamento dei valori di IN_2\n");   

        if(msg.end == STOP) break;

        if(msg.processo == IN_1){
            in1++;
            tot_in1+= msg.valore;
        }else{
            in2++;
            tot_in2+= msg.valore;
            
        }
    }
    printf("\nOUT: processo in1: %d, totale: %d\n", in1, tot_in1);
    printf("OUT: processo in2: %d, totale: %d\n", in2, tot_in2);
    exit(0);
}

int main(int argc, char* argv[]){   
    
    if(argc != 4){
        perror("parametri non sufficienti\n");
        exit(1);
    }

    char file[MAX_LEN];
    char query1[MAX_LEN];
    char query2[MAX_LEN];

    strcpy(file, argv[1]);
    strcpy(query1, argv[2]);
    strcpy(query2, argv[3]);

    int coda_IN_DB;
    int coda_DB_OUT;
    coda_IN_DB = msgget(IPC_PRIVATE, IPC_CREAT | IPC_EXCL | 0660);
    coda_DB_OUT = msgget(IPC_PRIVATE, IPC_CREAT | IPC_EXCL | 0660);

    if(!fork()) in(coda_IN_DB, query1, IN_1);
    if(!fork()) in(coda_IN_DB, query2, IN_2);
    if(!fork()) db(coda_IN_DB, coda_DB_OUT, file);
    if(!fork()) out(coda_DB_OUT);

    wait(NULL);
    wait(NULL);
    wait(NULL);
    wait(NULL);
    msgctl(coda_IN_DB, IPC_RMID, NULL);
    msgctl(coda_DB_OUT, IPC_RMID, NULL);
    return 0;
}