#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define IN1 1
#define IN2 2
#define DB 3
#define OUT 4

#define CONTINUE 100
#define STOP 101
#define MAX_LINE 1024

typedef struct{
    long mtype;
    int  mittente;
    char parola[MAX_LINE];
    int fine;
}msgin_db;

typedef struct{
    long mtype;
    int processo;
    int valore; 
    int fine;
}msgdb_out;

typedef struct{
    char parola[MAX_LINE];
    char valore[MAX_LINE];
}nodo;

void in1(int codain_db ,char* file){
    sleep(1);
    char buffer[MAX_LINE];
    FILE * in;
    in=fopen(file,"r");
    msgin_db messaggio;
    while (fgets(buffer,MAX_LINE,in)!=NULL){
        buffer[strcspn(buffer,"\n")]=0;
        messaggio.fine=CONTINUE;
        messaggio.mtype=DB;
        messaggio.mittente=IN1;
        strcpy(messaggio.parola,buffer);
        printf("IN1: sto per inviare la stringa <%s>\n", messaggio.parola);
        if(msgsnd(codain_db,&messaggio,sizeof(messaggio)-sizeof(long),0)==-1){
            perror(" in1 errore invio messaggio");
            exit(1);
        }

    }
    fclose(in);
    messaggio.fine=STOP;
    messaggio.mtype=DB;
    messaggio.mittente=IN1;
    if(msgsnd(codain_db,&messaggio,sizeof(messaggio)-sizeof(long),0)==-1){
        perror("in1 errore invio messaggio");
        exit(1);
    }
    exit(0);
    
}
void in2(int codain_db ,char *file){
    sleep(1);
    char buffer[MAX_LINE];
    FILE* in;
    in=fopen(file,"r");
    msgin_db messaggio;
    while (fgets(buffer,MAX_LINE,in)!=NULL){
        buffer[strcspn(buffer,"\n")]=0;
        messaggio.fine=CONTINUE;
        messaggio.mtype=DB;
        messaggio.mittente=IN2;
        strcpy(messaggio.parola,buffer);
        printf("IN2: sto per inviare la stringa <%s>\n", messaggio.parola);
        if(msgsnd(codain_db,&messaggio,sizeof(messaggio)-sizeof(long),0)==-1){
            perror(" in2 errore invio messaggio");
            exit(1);
        }

    }
    fclose(in);
    messaggio.fine=STOP;
    messaggio.mtype=DB;
    messaggio.mittente=IN2;
    if(msgsnd(codain_db,&messaggio,sizeof(messaggio)-sizeof(long),0)==-1){
        perror("in2 errore invio messaggio");
        exit(1);
    }
    exit(0);

}
void database(int codain_db ,int codadb_out,char* file){
    FILE* daatabase;
    daatabase=fopen(file,"r");
    int n_righe=0;
    char buffer[MAX_LINE];
    msgin_db m_ricevuto;
    msgdb_out m_snd;

    while(fgets(buffer,MAX_LINE,daatabase)!=NULL){
        n_righe++;
    }
    printf("n_righe: %d\n", n_righe);
    fclose(daatabase);
    nodo array[n_righe];
    int i=0;
    daatabase=fopen(file,"r");
    while(fgets(buffer,MAX_LINE,daatabase)!=NULL){
        strcpy(array[i].parola,strtok(buffer,":"));
        strcpy(array[i].valore,strtok(NULL,"\n"));
        i++;
    }
    
    for(int i=0;i<n_righe;i++){
        printf("[%s, %s]", array[i].parola, array[i].valore);
         
    }
    printf("\n");
    
  
    
    int flag = 0;
    int chiudi = 0;
    
    while(1){
        //printf("dio\n");
        if(msgrcv(codain_db,&m_ricevuto,sizeof(m_ricevuto)-sizeof(long),DB,0)==-1){
            perror(" errore nella ricezione");
            exit(1);
        }
       // printf("GESU CRSTo\n");
        printf(" %s",m_ricevuto.parola);
        printf("\n");
        if(m_ricevuto.fine==STOP) chiudi++;
        if(chiudi==2) break;
        for(int j=0;j<n_righe;j++){
            if(strcmp(m_ricevuto.parola,array[j].parola)==0){
                flag=1;
                printf("DB: ho trovato corrispondenza per la parola: <%s>\n", m_ricevuto.parola);
                m_snd.valore=atoi(array[j].valore);
                m_snd.processo=m_ricevuto.mittente;
                m_snd.mtype=OUT;
                m_snd.fine=CONTINUE;
                if(msgsnd(codadb_out,&m_snd,sizeof(m_snd)-sizeof(long),0)==-1){
                    perror("in2 errore invio messaggio");
                    exit(1);
                }                
                break;
            }
        }
        if(flag==0){
            printf("nussuna corrispondenza\n\n");
        }
    }
    m_snd.processo=m_ricevuto.mittente;
    m_snd.mtype=OUT;
    m_snd.fine=STOP;
    if(msgsnd(codadb_out,&m_snd,sizeof(m_snd)-sizeof(long),0)==-1){
        perror("in2 errore invio messaggio");
        exit(1);
    }            
    exit(0);
}

void output(int codadb_out){
    msgdb_out mex;
    int n_mex1=0;int n_mex2=0;
    int tot1=0;int tot2=0;
    while(1){
        if(msgrcv(codadb_out,&mex,sizeof(mex)-sizeof(long),OUT,0)==-1){
            perror(" errore 7");
            exit(1);
        }
        if(mex.fine==STOP)
            break;
        if(mex.processo==IN1){
            n_mex1++;
            tot1+=mex.valore;
        }
        else if(mex.processo==IN2){
            n_mex2++;
            tot2+=mex.valore;
        }
    }
    printf("\nOUT:ricevutu n %d valori validi per IN1 con totale % d\n",n_mex1,tot1);
    printf("OUT:ricevutu n %d valori validi per IN2 con totale % d\n",n_mex2,tot2);
    exit(0);
}
int main(int argc,char* argv[]){
    if(argc!=4){
        perror("errore nei parametri");
        exit(1);
    }

    int codain_db;
    int codadb_out;

    codain_db=msgget(IPC_PRIVATE,IPC_CREAT | 0660 | IPC_EXCL);
    codadb_out=msgget(IPC_PRIVATE,IPC_CREAT | 0660 | IPC_EXCL);

    if(!fork()) in1(codain_db,argv[2]);
    if(!fork()) in2(codain_db,argv[3]);
    if(!fork()) database(codain_db,codadb_out,argv[1]);
    if(!fork()) output(codadb_out);


    wait(NULL);
    wait(NULL);
    wait(NULL);
      printf("errore \n");
    wait(NULL);
    
    msgctl(codain_db,IPC_RMID,NULL);
    msgctl(codadb_out,IPC_RMID,NULL);

}