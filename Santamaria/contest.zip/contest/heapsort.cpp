/*#include <iostream>
#include <cstring>
#include <sstream>
#include <typeinfo>
#include<fstream>
using namespace std;
void swap(int& a,int& b){
    int tmp=b;
    b=a;
    a=tmp;
}
template<class H> class MaxHeap{
    public:
        H* array;
        int size;
        int heapsize;
        int counter_heapify;
        MaxHeap(int len){
            array=new H[len+1];
            size=len+1;
            heapsize=0;
            counter_heapify=0;
        }
        int left(int i){return i<<1;}
        int right(int i){return i<<1|1;}
        int parent(int i){return i>>1;}
        void insert(H val){
            heapsize++;
            array[heapsize]=val;
        }
        void heapify(int i){
            int l=left(i);
            int r=right(i);
            int max=i;
            if(l<=heapsize && array[l]>array[max]) max=l;
            if(r<=heapsize && array[r]>array[max]) max=r;
            if(i!=max){
                swap(array[i],array[max]);
                heapify(max);
            }
            if(heapsize>=1) counter_heapify++;
        }
        void build(){
            for(int i=heapsize/2;i>0;i--){
                heapify(i);
            }
        }
        H extract(){
            swap(array[1],array[heapsize]);
            heapsize--;
            heapify(1);
            return array[heapsize+1];
        }
        void heapsort(ofstream& output){
            build();
            H* a;
            a=new H[heapsize+1];
            for(int i=heapsize;i>0;i--){
                a[i]=extract();
            }
            output<<counter_heapify<<'\t';
            for(int i=1;i<size;i++){
                array[i]=a[i];
                output<<array[i]<<'\t';
            }
            output<<endl;

        }
       /* void stampa(ofstream& output){
            output<<counter_heapify<<'\t';
            for(int i=1;i<=heapsize;i++){
                output<<array[i]<<'\t';
            }
            output<<endl;
        }*/
    
/*};
template<class H> void parsing(ifstream& input,ofstream& output){
    int n;
    input>>n;
    H elem;
    MaxHeap<H>* heap=new MaxHeap<H> (n);
    for(int i=0;i<n;i++){
        input>>elem;
        heap->insert(elem);
    }
   // output<<heap->counter_heapify;
    heap->heapsort(output);
    //heap->stampa(output);
}
int main(){
    ifstream input;
    ofstream output;
    input.open("inputheapsort.txt");
    output.open("outputheapsort.txt");
    string tipo;
    for(int i=0;i<3;i++){
        input>>tipo;
        switch (tipo[0])
        {
        case 'i':
            parsing<int>(input,output);
            break;
        case 'd':
            parsing<double>(input,output);
            break;
        case 'c':
            parsing<char>(input,output);
            break;
        case 'b':
            parsing<bool>(input,output);
            break;
        default:
            break;
        }
    }
}*/
#include <iostream>
#include<cstring>
#include<fstream>
#include<sstream>
using namespace std;
void swap(int& a,int& b){
    int tmp=b;
    b=a;
    a=tmp;
}
template <class H> class MaxHeap{
    public:
        H* array;
        int size;
        int heapsize;
        int countheap;
        MaxHeap(int len){
            size=len+1;
            array=new H[size];
            heapsize=0;
            countheap=0;
        }
        int left(int i){return i<<1;}
        int right(int i){return (i<<1)|1;}
        int parent(int i){return i>>1;}
        void heapify(int i){
            int r=right(i);
            int l=left(i);
            int max=i;
            if(l<=heapsize && array[l]>array[max]) max =l;
            if(r<=heapsize && array[r]>array[max]) max =r;
            if(i!=max){
                swap(array[i],array[max]);
                heapify(max);
            }
            if(heapsize>=1)countheap++;
        }
        void insert(int n,ifstream& input){
            H elem;
            for(int i=1;i<=n;i++){
                input>>elem;
                array[i]=elem;
            }
        }
        void build(int n){
            heapsize=n;
            for(int i=heapsize/2;i>=1;i--)
                heapify(i);
        }
        H extract(){
            swap(array[1],array[heapsize]);
            heapsize--;
            heapify(1);
            return array[heapsize+1];
        }
        void heapsort(int n){
            H elem;
            for(int i=0;i<n;i++){
                elem=extract();
                cout<<elem<<'\t';
            }
            cout<<endl;
        }
        void stampa(ofstream& output){
            for(int i=1;i<size;i++){
                output<<array[i]<<'\t';
            }
        }
};
template<class H> void parsing(ifstream& input,ofstream& output){
    int n;
    input>>n;
    MaxHeap<H>* heap=new MaxHeap<H> (n);
    heap->insert(n,input);
    heap->build(n);
    heap->heapsort(n);
    output<<heap->countheap<<'\t';
    heap->stampa(output);
    output<<endl;
}
int main(){
    ifstream input;
    ofstream output;
    input.open("input.txt");
    output.open("output.txt");
    string tipo;
    for(int i=0;i<100;i++){
        input>>tipo;
        switch (tipo[0])
        {
        case 'i':
            parsing<int>(input,output);
            break;
        case 'b':
            parsing<bool>(input,output);
            break;
        case 'c':
            parsing<char>(input,output);
            break;
        case 'd':
            parsing<double>(input,output);
            break;
        default:
            break;
        }
    }
}