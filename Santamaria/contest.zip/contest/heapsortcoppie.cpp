#include <iostream>
#include <cstring>
#include <fstream>

using namespace std;
void swap(int& a, int& b){
    int tmp=b;
    b=a;
    a=tmp;
}
template <class H> struct Nodo{
    H val;
    H val1;
};
template <class H> class MaxHeap{
    public:
        Nodo<H>** array;
        int heapsize;
        int size;
        int count_heapfy;
        MaxHeap(int len ){
            array =new Nodo<H>* [len+1];
            for(int i=1;i<len+1;i++){
                array[i]=new Nodo<H>;
            }
            size=len+1;
            heapsize=0;
            count_heapfy=0;
        }
        void insert(ifstream& input){
            heapsize++;
            char c;
            input>>c;
            input>>array[heapsize]->val;
            input>>c;
            input>>array[heapsize]->val1;
            input>>c;
        }
        int left(int i){return i<<1;}
        int right(int i){return i<<1|1;}
        int parent(int i){return i>>1;}
        void heapfy(int i){
            int r=right(i);
            int l=left(i);
            int max=i;
            if(l<=heapsize && array[l]->val>=array[max]->val ){
                if(array[l]->val==array[max]->val){
                    if(array[l]->val1>array[max]->val1) 
                        max=l;
                }
                else max=l;           
            }   
            if(r<=heapsize && array[r]->val>=array[max]->val ){
                if(array[r]->val==array[max]->val){
                    if(array[r]->val1>array[max]->val1) 
                        max=r;
                } 
                else max=r;          
            }
            if(i!=max){
                swap(array[i],array[max]);
                heapfy(max);
            }
            if(heapsize>=1) count_heapfy++;
        } 
        Nodo<H>* extract_max(){
            swap(array[heapsize],array[1]);
            heapsize--;
            heapfy(1);
            return array[heapsize+1];
        }
        void build(int n){
            heapsize=n;   
            for(int i=heapsize/2 ;i>=1;i--){
                heapfy(i);
            }
        } 
        void heapsort(){
            Nodo<H>** b;
            b=new Nodo<H>* [size];
            for(int i=1;i<=size;i++){
                b[i]=new Nodo<H>;
            }
            for(int i=size;i>0;i--){
                b[i]=extract_max();
            }
            for(int i=1;i<=size;i++){
                array[i]=b[i];
            }
            delete[] b;
        }
        void stampa(ofstream& output){
            cout<<"wee"<<endl;
            output<<count_heapfy<<'\t';
            for(int i=1;i<=size;i++){
                output<<'('<<array[i]->val<<','<<array[i]->val1<<')';
                cout<<i<<endl;
            }
        }     
};
template<class H> void parsing(ifstream& input,ofstream& output){
    int n;
    input>>n;
    MaxHeap<H>* heap=new MaxHeap<H> (n);
    H elem;
    char c;
   // input>>c;
    cout<<" endnd"<<endl;
    for(int i=0;i<n;i++){
        heap->insert(input);
       /* input>>c;
        input>>heap->array[i+1]->val;
        input>>c;
        input>>heap->array[i+1]->val1;
        input>>c;*/
    }
    cout<<endl;
    heap->build(n);
    cout<<"buil"<<endl;
    heap->heapsort();
    cout<<"sort"<<endl;
    heap->stampa(output);
    cout<<"stampa"<<endl;
    output<<endl;
}
int main(){
   ifstream input;
   ofstream output;
   input.open("iheapsortcoppie.txt");
   output.open("oheapsortcoppie.txt");
   string tipo;
   for(int i=0;i<3;i++){
       input>>tipo;
       switch(tipo[0]){
           case 'i':
                parsing<int>(input,output);
                break;
            case 'b':
                parsing<bool>(input,output);
                break;
            case 'd':
                parsing<double>(input,output);
                break;
            case 'c':
                parsing<char>(input,output);
                break;
       }
   }/*
   MaxHeap<int>* a=new MaxHeap<int> (10);
   for(int i=0;i<=10;i++){
   a->array[i]->val=rand();
   a->array[i]->val1=rand();
   }*/
}