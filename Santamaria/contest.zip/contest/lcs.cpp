#include<iostream>
#include <cstring>
#include <fstream>
#include <sstream>
using namespace std;
int LCS(string a,string b){
     int ** M;
     M=new int*[a.length()];
     for(int i=0;i<a.length();i++){
         M[i]=new int[b.length()];
     }
    for(int i=0;i<a.length();i++){
        for(int j=0;j<b.length();j++){
            M[i][j]=0;
         }
    }
    for(int i=0;i<a.length();i++){
        for(int j=0;j<b.length();j++){
            if(i==0 || j==0)
                M[i][j]=0;
            else if(a[i]==b[j]){
                M[i][j]=M[i-1][j-1]+1;
                
            }
            else if(a[i]!=b[j])
                M[i][j]=max(M[i-1][j],M[i][j-1]);
         }
     }
     return M[a.length()-1][b.length()-1];
}
int main(){
    string a="";
    string b="";
    int n;
    ifstream input;
    ofstream output;
    input.open("ilcs.txt");
    output.open("olcs.txt");
    for(int i=0;i<3;i++){
        input>>n;
        input>>n;
        input>>a;
        a="0"+a;
        input>>b;
        b="0"+b;
        cout<<LCS(a,b)<<endl;
    }
}