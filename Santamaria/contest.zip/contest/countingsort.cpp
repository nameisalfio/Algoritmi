#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
 void stampa(int* a,int size,ofstream& output){
     for(int i=0;i<size;i++) output<<a[i]<<'\t';
 }
 void counting_sort(int *a,int n,ofstream& output){
     int min=a[0];
     int max=a[0];
     for(int i=1;i<n;i++){
         if(a[i]>max) max=a[i];
         else if(a[i]<min) min=a[i];
     }
     int range=max-min+1;
     int *c =new int [range];
     for(int i=0;i<range;i++) c[i]=0;
     for(int i=0;i<n;i++) c[a[i]-min]++;
     for(int i=1;i<range;i++) c[i]+=c[i-1];
     int *b=new int [n];
     cout<<"dio"<<endl;
     for(int i=n-1;i>=0;i--){
         b[c[a[i]-min]-1]=a[i];
         c[a[i]-min]--;

     }   
     for(int i=0;i<n;i++) a[i]=b[i];
     stampa(c,range,output);
     
     delete[] c;
     delete[] b;
     }
     int main(){
         ifstream input;
         ofstream output;
         input.open("icountingsort.txt");
         output.open("ocountingsort.txt");
         int n;
         for(int i=0;i<3;i++){
             input>>n;
             int *array=new int [n];
             for(int j=0;j<n;j++){
                 input>>array[j];
             }
             
             counting_sort(array,n,output);
             stampa(array,n,output);
             delete[] array;
             output<<endl;
         }
     }