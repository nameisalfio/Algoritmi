#include <iostream>
#include <cstring>
#include <fstream>
#include <sstream>
using namespace std;
void print(int *a,int n,ofstream& output){
    for(int i=0;i<n;i++){
        cout<<i<<'\t';
    }
    cout<<endl;
    for(int i=0;i<n;i++){
        output<<a[i]<<'\t';
    }
   // output<<endl;
} 
class Coppia{
    public:
        double val;
        double val1;
        Coppia(double val,double val1){
            this->val=val;
            this->val1=val1;
        }
        double getval(ofstream& output){
            output<<" ("<<val<<',';
            return val;
        }
        double getval1(ofstream& output){
            output<<val1<<" ) ";
            return val1;
        }
        void set(double val,double val1){
            this->val=val;
            this->val1=val1;
        }
        friend  bool operator>(Coppia& a,Coppia& b ){
            if(a.val>b.val) return 1;
            else if(a.val==b.val && a.val1>b.val1) return 1;
            return 0;
        }

};
int maxm(int* a,int n){
    int max=a[0];
    for(int i=0;i<n;i++){
        if(a[i]>max)
            max=a[i];
    }
    return max;
}
void swap(Coppia a,Coppia b){
    Coppia* tmp=new Coppia(b.val,b.val1);
    b.set(a.val,b.val);
    a.set(tmp->val,tmp->val1);
}
int minimo(int* a,int n){
    int min=a[0];
    for(int i=0;i<n;i++){
        if(a[i]<min)
            min=a[i];
    }
    return min;
}
void printB(Coppia** B,int n,ofstream& output){
    for(int i=0;i<n;i++){
        cout<<i<<'\t';
    }
    cout<<endl;
    for(int i=0;i<n;i++){
        B[i]->getval(output);
        B[i]->getval1(output);
    }
}
Coppia** counting_sort(Coppia **a,int n, ofstream& output){
    int *A;
    double *r;n
    r=new double[n];
    A=new int [n];
    for(int i=0;i<n;i++){
        A[i]=a[i]->val*10;
        r[i]=a[i]->val1*10;
        cout<<a[i]->val*10<<endl;
       // cout<<a[i]->val1*10<<endl;
    }
    int min=minimo(A,n);
    int max=maxm(A,n);
    int range=max-min+1;
    cout<<"max "<<max<<endl;
    cout<<"min "<<min<<endl;
    cout<<"range "<<range<<endl;
    int *c=new int[range];
    for(int i=0;i<range;i++) c[i]=0;
    for(int i=0;i<n;i++) c[A[i]-min]++;
    for(int i=1;i<range;i++) c[i]+=c[i-1];
    Coppia **B;
    B=new Coppia* [n];
    int diff;
    //print(A,n);
    for(int i=n-1;i>=0;i--){
        B[c[A[i]-min]-1]=new Coppia(A[i]/10.0,r[i]/10); 
        c[A[i]-min]--;
    }
    for(int i=1;i<n;i++){
        if(*B[i-1]>*B[i])
            swap(B[i-1],B[i]);
    }
    print(c,range,output);
    //print(c,range); 
    //printB(B,n,output);
    return B;
}
  
int main(){
    ifstream input;
    ofstream output;
    input.open("icoppiec.txt");
    output.open("ocoppiec.txt");
    int n;
    double elem;
    double elem1;
    char c;
    for(int i=0;i<1;i++){
        input>>n;
        Coppia** a=new Coppia* [n];
        for(int i=0;i<n;i++){
            input>>c;
            input>>elem;
            input>>c;
            input>>elem1;
            input>>c;
            a[i]=new Coppia(elem,elem1);
        }
        Coppia** result;
        result=counting_sort(a,n,output);
        printB(result,n,output);
        output<<endl;
    }
}