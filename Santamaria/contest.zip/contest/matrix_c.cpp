#include <iostream>
#include <cstring>
#include <fstream>
#include <sstream>
#include <climits>
using namespace std;
int moltiplicazioni(int *a ,int n){
    int m[n][n];
    for(int i=0;i<n;i++) m[i][i]=0;
    for(int d=2;d<n;d++){
        for(int i=1;i<d;i++){
            int j=d-1+i;
            m[i][j]=INT16_MAX;
            for(int k=i;k<j;k++){
                int q=m[i][k]+m[k+1][j]+a[i-1]*a[k]-a[j];
                if(q<m[i][j]) m[i][j]=q;
            }
        }
    }
    return m[1][n-1];
}