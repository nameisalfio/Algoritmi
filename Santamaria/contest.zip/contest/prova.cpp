#include <iostream>
#include <cstring>
#include <fstream>
#include <sstream>
using namespace std;
class Coppia{
    private: 
        double val,val2;
    public:
        Coppia(double val,double val2){
            this->val2=val2;
            this->val=val;
        }
        void set(double a,double b){
            this->val=a;
            this->val2=b;
        }
        double  get_val(){
            return val;
        }
        double get_val2(){
            return val2;
        }
        bool friend operator >(Coppia& a,Coppia& b){
            if(a.val>b.val) return 1;
            else if(a.val ==b.val && a.val2>b.val2)return 1;
            return 0;
        }
};
void swap(Coppia* a,Coppia* b){
    Coppia *tmp=new Coppia(b->get_val(),b->get_val2());
    b->set(a->get_val(),a->get_val2());
    a->set(tmp->get_val(),tmp->get_val2());
}
double smax(Coppia** a,int n){
    double max;
    max=a[0]->get_val();
    for(int i=1;i<n;i++){
        if(a[i]->get_val()>max)
            max=a[i]->get_val();
    }
    return max;
}
double smin(Coppia** a,int n){
    double min;
    min=a[0]->get_val();
    for(int i=1;i<n;i++){
        if(a[i]->get_val()<min)
            min=a[i]->get_val();
    }
    return min;
}
Coppia** insert(int n,ifstream& input){
    char c;
    double a,b;
    Coppia** array;
    array=new Coppia* [n];
    for(int i=0;i<n;i++){
        input>>c;
        input>>a;
        input>>c;
        input>>b;
        input>>c;
        array[i]=new Coppia(a*10.0,b*10.0);
    }
    return array;
}
void stampa(int *a,int n,ofstream& output){
    for(int i=0;i<n;i++){
        output<<a[i]<<'\t';
    }
}
void stampaC(Coppia** array,int n,ofstream& output){
    for(int i=0;i<n;i++){
        output<<"("<<array[i]->get_val()<<","<<array[i]->get_val2()<<")";
    }
}
void Counting(Coppia** array, int n,ofstream& output){
    int * c;
    int min=smin(array,n);
    int k=smax(array,n)-min+1;
    c=new int [k];
    for(int i=0;i<k;i++){
        c[i]=0;
    }
    for(int i=0;i<n;i++){
        c[(int)array[i]->get_val()-min]++;
    }
    for(int i=1;i<k;i++){
        c[i]+=c[i-1];
    }
    Coppia **B;
    B=new Coppia* [n];
    for(int i=n-1;i>=0;i--){
        B[c[(int)array[i]->get_val()-min]-1]=new Coppia(array[i]->get_val()/10.0,array[i]->get_val2()/10.0);
        //B[c[array[i]->get_val()-min]-1]=array[i]->get_val()/10;
        c[(int)array[i]->get_val()-min]--;
    }
    for(int i=1;i<n;i++){
            if(*B[i-1]>*B[i])
                swap(B[i],B[i-1]);
    }
    for(int i=1;i<n;i++){
            if(*B[i-1]>*B[i])
                swap(B[i],B[i-1]);
    }
    stampa(c,k,output);
    delete c;
    stampaC(B,n,output);
    delete B;
    //return B;
}

int main(){
    ifstream input;
    ofstream output;
    int n;
    input.open("icoppiec.txt");
    output.open("ocoppiec2.txt");
    for(int i=0;i<2;i++){
        input>>n;
        Coppia ** arr;
        arr=insert(n,input);
        Counting(arr, n,output);
        output<<endl;
        delete arr;
    }
}