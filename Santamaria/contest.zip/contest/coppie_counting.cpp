#include<iostream>
#include <cstring>
#include <fstream>
#include  <sstream>
using namespace std;
struct  Nodo_int{
        int val;
        int val2;
};
struct Nodo_double{
    double val;
    double val2;
};
double* coutning_sort(Nodo_double* a,int n,ofstream& output){
    Nodo_int *A=new Nodo_int[n];
    Nodo_int min->val=a[0]->val;min->val2=a[0]->val2;
    Nodo_int max->val=a[0]->val; max->val2=a[0]->val2;
    for(int i=0;i<n;i++){
        A[i]->val=(int)(a[i]->val*10);
        A[i]->val2=(int )(a[i]->val2*10);
        if(min->val>=A[i]->val ){
            if(min->val==A[i]->val && min->val2>A[i]->val2)
                min=A[i];
            else min=A[i];
        } 
        if(max->val<=A[i]->val){
            if(max->val==A[i]->val && max->val2>A[i]->val2) 
                max=A[i];
            else max=A[i];
        }    
    }
    int range=max-min+1;
    int* C=new int[range];
    for(int i=0;i<range;i++)C[i]=0;
    for(int i=0;i<n;i++)C[A[i]-min]++;
    for(int i=1;i<range;i++) C[i]+=C[i-1];
    double* B;
    B=new double[n];
    for(int i=n-1;i>=0;i--){
        B[C[A[i]-min]-1]=A[i]/10.0;
        C[A[i]-min]--;
    }
    stampa(C,range,output);
    return B;
}
void stampa(double* b,int n,ofstream& output){
    for(int i=0;i<n;i++)
        output<<b[i]<<'\t';
}
void insert(ifstream& input,ofstream& output){
    int n;
    input>>n;
    char c;
    double *A=new int[n];
    for(int i=0;i<n;i++){
        input>>c;
        input>>A[i];
        input>>c;

    }
    double *result=new double[n]
}
int main(){
    

}