#include <iostream>
#include <fstream>
#include<cstring>
using namespace std;
template<class H> void stampa(H* a,int n,ofstream& output){
    for(int i=0;i<n;i++)
        output<<a[i]<<'\t';
   // output<<endl;
}
template<class H> H* counting_sort(H* a,int n,ofstream& output){
    int *A;
    A=new int[n];
    int min=a[0];
    int max=a[0];
    for(int i=0;i<n;i++){
        A[i]=(int)(a[i]);
        if(A[i]<min) min=A[i];
        if(A[i]>max) max=A[i]; 
    }
    int range=max-min+1;
    cout<<range<<endl;
    int *C=new int[range];
    for(int i=0;i<range;i++) C[i]=0;
    for(int i=0;i<n;i++) C[A[i]-min]++;
    for (int i=1;i<range;i++) C[i]=C[i]+C[i-1];
    H* B;
    B=new H[n];
    for(int i=n-1;i>=0;i--){
        B[C[A[i]-min]-1]=A[i];
        C[A[i]-min]--;
    }
    stampa(C,range,output);
    return B;
};
double* counting_sort(double* a,int n,ofstream& output){
     int *A;
    A=new int[n];
    int min=a[0];
    int max=a[0];
    for(int i=0;i<n;i++){
        A[i]=(int)(a[i]*10);
        if(A[i]<min) min=A[i];
        if(A[i]>max) max=A[i]; 
    }
    int range=max-min+1;
    int *C=new int[range];
    for(int i=0;i<range;i++) C[i]=0;
    for(int i=0;i<n;i++) C[A[i]-min]++;
    for (int i=1;i<range;i++) C[i]=C[i]+C[i-1];
    double* B;
    B=new double[n];
    for(int i=n-1;i>=0;i--){
        B[C[A[i]-min]-1]=A[i]/10.0;
        C[A[i]-min]--;
    }
    stampa(C,range,output);
    return B;
}
template <class H> void parsing(ifstream& input,ofstream& output){
    int n;
    input>>n;
    H* a;
    a=new H[n];
    for(int i=0;i<n;i++){
        input>>a[i];
     //   cout<<a[i]<<'\t';
    }
    H* result;
    result=new H[n];
    result=counting_sort(a,n,output);
    stampa(result,n,output);
    output<<endl;
}
int main(){
    ifstream input;
    ofstream output;
    input.open("iordinamentolineare.txt");
    output.open("oordinamentolineare.txt");
    string tipo;
    for(int i=0;i<3;i++){
        input>>tipo;
        switch (tipo[0])
        {
        case 'i':
            parsing<int>(input,output);
            break;
        case 'c':
            parsing<char>(input,output);
            break;
        case 'b':
            parsing<bool>(input,output);
            break;
        case 'd':
            parsing<double>(input,output);
            break;
        default:
            break;
        }
    }
}