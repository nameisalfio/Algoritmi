#include <iostream>
#include <cstring>
#include <fstream>
#include <sstream>
using namespace std;
class Activity{
    public:
        int s;
        int f;
        Activity(int s ,int f){
            this->f=f;
            this->s=s;
        }
        void set(int s,int f){
            this->s=s;
            this->f=f;
        }
};
void swap(Activity* a,Activity* b){
    Activity* tmp=new Activity(b->s,b->f);
    b->set(a->s,a->f);
    a->set(tmp->s,tmp->f);
}
void sort(Activity ** a,int n){
    for(int i=0;i<n-1;i++){
        for(int j=i+1;j<n;j++){
            if(a[j]->f<a[i]->f) swap(a[i],a[j]);
            else if (a[j]->f==a[i]->f && a[j]->s<a[i]->s) swap(a[i],a[j]);
        }
    }
}
void stampa(Activity** a,int n){
    for(int i=0;i<n;i++){
        cout<<a[i]->s<<'\t';
    }
    cout<<endl;
    for(int i=0;i<n;i++){
        cout<<a[i]->f<<'\t';
    }
    cout<<endl;
    cout<<endl;
}
void selector(Activity** a,int n,ofstream& output ){
    sort(a,n);
    stampa(a,n);
    int count=1;
    int l=0;
    for(int i=1;i<n;i++){
        if(a[i]->s>=a[l]->f){
            count++;
            l=i;
            }   
    }
    output<<count<<endl;
}
int main(){
    ifstream input;
    ofstream output;
    input.open("igactivity.txt");
    output.open("ogactivity.txt");
    int n;
    char c;
    int e,ele;
    for(int i=0;i<3;i++){
        input>>n;
        Activity **a;
        a=new Activity* [n];
        for(int i=0;i<n;i++){
            input>>c;
            input>>e;
            input>>c;
            input>>ele;
            input>>c;
            a[i]=new Activity(e,ele);
        }    
        selector(a,n,output);
    }
}