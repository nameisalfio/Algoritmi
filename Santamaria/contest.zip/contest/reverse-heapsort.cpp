#include <iostream>
#include <fstream>
#include <cstring>
#include <sstream>
#include <typeinfo>
using namespace std;
void swap(int& a,int& b){
    int tmp=b;
    b=a;
    a=tmp;
}
template<class H> class MaxHeap{
    public:
        H* array;
        int size;
        int heapsize;
        int countheapify;
        MaxHeap(int len){
            size=len+1;
            array=new H[size];
            heapsize=0;
            countheapify=0;
        }
        int left(int i){return i<<1;}
        int right(int i){return (i<<1)|1;}
        int parent(int i){return i>>1;}
        void heapify(int i){
            int r=right(i);
            int l=left(i);
            int max=i;
            if(l<=heapsize && array[l]<array[max]) max=l;
            if(r<=heapsize && array[r]<array[max]) max=r;
            if(i!=max){
                swap(array[max],array[i]);
                heapify(max);
            }
            if(heapsize>=1)countheapify++;
        }
        void build(int n){
            heapsize=n;
            for(int i=heapsize/2;i>=1;i--)
                heapify(i);
        }
        void insert(int n,ifstream& input){
            H elem;
            for(int i=1;i<=n;i++){
                input>>elem;
                array[i]=elem;
            }
        }
    void extract(){
            swap(array[1],array[heapsize]);
            heapsize--;
            heapify(1);
        //    return array[heapsize+1];
        }
        void heapsort(int n){
            for(int i=0;i<n;i++){
                extract();
            }
        }
        void stampap(ofstream& output){
            for(int i=1;i<size;i++)
                output<<array[i]<<'\t';
            output<<endl;
        }
};
template <class H> void parsing(ifstream& input,ofstream& output){
    int n;
    input>>n;
    MaxHeap<H>* heap=new MaxHeap<H> (n);
    heap->insert(n,input);
    heap->build(n);
    heap->heapsort(n);
    output<<heap->countheapify<<'\t';
     cout<<"dioc"<<endl;
    heap->stampap(output);
     cout<<"dioc"<<endl;
}
int main(){
    ifstream input;
    ofstream output;
    input.open("input.txt");
    output.open("output.txt");
    string tipo;
    for(int i=0;i<100;i++){
        input>>tipo;
        switch (tipo[0])
        {
        case 'i':
            parsing<int>(input,output);
            break;
        case 'b':
            parsing<bool>(input,output);
            break;
        case 'c':
            parsing<char>(input,output);
            break;
        case 'd':
            parsing<double>(input,output);
            break;
        default:
            break;
        }
    }
}