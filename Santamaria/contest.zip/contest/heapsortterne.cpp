#include <iostream> 
#include <cstring>
#include <typeinfo>
#include <fstream>
#include <sstream>
using namespace std;
template <class H> struct Nodo{
    H val1;
    H val2;
    H val3;
};
void swap(int&  a,int& b){
    int tmp=b;
    b=a;
    a=tmp;
}
template<class H> class MaxHeap{
    public:
        Nodo<H>** array;
        int heapsize;
        int size;
        int  count_heapfy;
        MaxHeap(int len){
            size=len+1;
            array=new Nodo<H>* [size];
            for(int i=1;i<size;i++){
                array[i]=new Nodo<H>;
            }
            heapsize=0;
            count_heapfy=0;
        }
        int left(int i){return i<<1;}
        int right(int i){return i<<1|1;}
        int parent(int i){return i>>1;}
        void insert(ifstream& input){
            stringstream s;
            H elem;
            char c;
            input>>c;
            heapsize++;
            input>>array[heapsize]->val1;
            input>>elem;
            if(elem==','){
                c=elem;
                input>>elem;
                array[heapsize]->val2=elem;
            }    
            else array[heapsize]->val2=elem;
            	input>>elem;
            if(elem==','){
                c=elem;
                input>>elem;
                array[heapsize]->val3=elem;
            }
            else array[heapsize]->val3=elem;
            input>>c;


        }
        void insert1(ifstream& input){
            H elem;
            char c;
            input>>c;
            heapsize++;
            input>>array[heapsize]->val1;
            cout<<array[heapsize]->val1<<endl;
            input>>c;
            input>>elem;
            cout<<elem<<endl;
            array[heapsize]->val2=elem;
            input>>c;
            input>>elem;
            cout<<elem<<endl;
            array[heapsize]->val3=elem;
            input>>c;
            cout<<endl;

        }
        void heapfy(int i){
            int r=right(i);
            int l=left(i);
            int max=i;
            //cout<<" ok "<<endl;
            if(r<=heapsize && array[r]->val1>=array[max]->val1){
                //cout<<"ok"<<endl;
                if(array[r]->val1==array[max]->val1) {
                    if(array[r]->val2>=array[max]->val2){
                        if(array[r]->val2==array[max]->val2){
                            if (array[r]->val3>array[max]->val3)
                                max=r;
                        }
                    }   
                }
                else max=r;
            }
            if(l<=heapsize && array[l]->val1>=array[max]->val1){
                if(array[l]->val1==array[max]->val1) {
                    if(array[l]->val2>=array[max]->val2){
                        if(array[l]->val2==array[max]->val2){
                            if (array[l]->val3>array[max]->val3)
                                max=l;
                        }
                    }   
                }
                else max=l;
            }
          
            //cout<<"ok "<<endl;
            if(i!=max){
                swap(array[i],array[max]);
                heapfy(max);
            }
            if(heapsize>=1) count_heapfy++;
        }
        void build(int n){
            heapsize=n;
            for(int i=heapsize/2;i>0;i--){
                cout<<"sis"<<endl;
                heapfy(i);
            }
        }
        Nodo<H>* extract(){
            swap(array[1],array[heapsize]);
            heapsize--;
            heapfy(1);
            return array[heapsize+1];
        }
        void stampa(ofstream& output ){
            output<<count_heapfy<<'\t';
            for(int i=1;i<size;i++){
                output<<"("<<array[i]->val1<<'\t'<<array[i]->val2<<'\t'<<array[i]->val3<<")";
            }
            output<<endl;

        }
        void heapsort(){
            Nodo<H>** b;
            b=new Nodo<H>* [size];
            for(int i=1;i<size;i++){
                b[i]=new Nodo<H>;
            }
            for(int i=size-1;i>0;i--){
                b[i]=extract();
            }
            for(int i=1;i<size;i++){
                array[i]=b[i];
            }
            delete[] b;
        }
};
template<class H> void parsing(ifstream& input, ofstream& output){
    int n;
    input>>n;
    MaxHeap<H>* heap=new MaxHeap<H> (n);
    H elem;
    for(int i=0;i<n;i++){
        heap->insert(input);
    }
    heap->build(n);
    heap->heapsort();
    heap->stampa(output);
}
int main(){
    ifstream input;
    ofstream output;
    input.open("iterneheap.txt");
    output.open("oterneheap.txt");
    string s;
    for(int i=0;i<3;i++){
        input>>s;
        switch (s[0])
        {
        case 'i':
            parsing<int>(input,output);
            break;
        case 'd':
            parsing<double>(input,output);
            break;
        case 'b':
            parsing<bool>(input,output);
            break;
        case 'c':
            parsing<char>(input,output);
            break;
        default:
            break;
        }
    }
return 0;
}
