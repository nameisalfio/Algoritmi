#include<iostream>
#include<fstream>
#include<cstring>
#include<cctype>
#include<climits>

using namespace std;

class Ponte {
	public:
    		int from, to, cost;
    		Ponte() {
        	from=to=cost=0;
    		}

    		Ponte(int from, int to, int cost) {
        		this->from=from;
        		this->to=to;
        		this->cost=cost;
    		}
};

template <class H> class Graph {
private:
    H* nodes;
    Ponte** edges;

    int search(H elem) {
        int k=0;
        while(k<current_nodes && nodes[k]!=elem) k++;
        if(k==current_nodes) return -1;
        return k;
    }

    int get_min(int* vett) {
        int min=-1;
        for(int i=1; i<current_nodes; i++) {
            if(vett[i]<vett[i-1]) min=i;
        }
        if(min<0) return -1;
        return min;
    }

public:
    int size_nodes, size_edges, current_nodes, current_edges;

    Graph(int size_nodes) {
        this->size_nodes=size_nodes;
        size_edges=size_nodes*size_nodes;
        current_nodes=current_edges=0;
        nodes=new H[this->size_nodes];
        edges=new Ponte*[this->size_edges];
    }

    Graph* insert_node(H elem) {
        if(current_nodes<size_nodes) {
            nodes[current_nodes]=elem;
            current_nodes++;
        }
        return this;
    }

    Graph* insert_edge(H a, H b, int cost) {
        if(current_edges<size_edges) {
            int index_a=search(a);
            int index_b=search(b);
            if(index_a<0 || index_b<0) return this;
            edges[current_edges]=new Ponte(index_a, index_b, cost);
            current_edges++;
        }
        return this;
    }

    string dijkstra(H source, H destination) {
        string result="inf";
        int* pred=new int[size_nodes];
        int start=search(source);
        int end=search(destination);
        if(start<0 || end<0) return " ";
        int* costs=new int[size_nodes];
        for(int i=0; i<size_nodes; i++) {
            costs[i]=INT_MAX;
            pred[i]=INT_MAX;
        }
        costs[start]=0;
        pred[start]=-1;
        int tmp;
        for(int i=0; i<size_nodes; i++) {
            int tmp=get_min(costs);
            for(int k=0; k<current_edges; k++) {
                if(costs[edges[k]->from]!=INT_MAX && costs[edges[k]->from] + edges[k]->cost<costs[edges[k]->to]) {
                    pred[edges[k]->to]=tmp;
                    costs[edges[k]->to]=costs[edges[k]->from]+edges[k]->cost;
                }
            }
        }
        if(costs[end]!=INT_MAX) result=to_string(costs[end]);
        delete[] costs;
        delete[] pred;
        return result;
    }
};

template <class H> void parsing(int N, int M, ifstream& input, ofstream& output) {
    Graph<H>* graph=new Graph<H>(N);
    H elem1;
    H elem2;
    H costo;
    H sorgente;
    H destinazione;
    char cIgnore;
    for(int i=0; i<N; i++) {
        input >> elem1;
        graph->insert_node(elem1);
        }
    for(int i=0; i<M; i++) {
        input >> cIgnore;
        input >> elem1;
        input >> elem2;
        input >> costo;
        input >> cIgnore;
        graph->insert_edge(elem1,elem2,costo);
        }
    input >> sorgente;
    input >> destinazione;
    output << graph->dijkstra(sorgente,destinazione);
    output << endl;
    }

int main() {
    ifstream input;
    ofstream output;
    input.open("input.txt");
    output.open("output.txt");
    for(int task=0; task<100; task++) {
        int N;
        int M;
        string tipo;
        input >> N;
        input >> M;
        input >> tipo;
        switch (tipo[0]) {
            case 'i':
                parsing<int>(N,M,input,output);
                break;
            case 'c':
                parsing<char>(N,M,input,output);
                break;
            case 'd':
                parsing<double>(N,M,input,output);
                break;
            case 'b':
                parsing<bool>(N,M,input,output);
                break;
        }
    }
}
