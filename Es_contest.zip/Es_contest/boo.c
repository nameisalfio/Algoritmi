#include<stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/msg.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <fcntl.h>

#define MAX_LEN 1024 
#define S 1
#define C 2 
typedef struct{
    long mtype;
    char string[MAX_LEN];
    char string2[MAX_LEN];
    int risultato;
}msg;

void Sorter(int coda,char* file,char M[][MAX_LEN],int numero_righe){
    FILE* in;
    int indice = 0;
    in=fopen(file,"r");
    msg messaggio;
    msg ricevuto;
    char tmp[MAX_LEN];
    char buffer[MAX_LEN];
    while(fgets(buffer,MAX_LEN,in)!=NULL ){
        //buffer[strcspn(buffer,"/n")] = 0 ;
        strcpy(M[indice],buffer);
        //M[indice][strcspn(buffer,"/n")] = 0 ;
        //printf("%s  e  %s \n ",M[indice],buffer);
        indice++;
    }
    for(int i=0;i<indice-1;i++){
        for(int j=i+1;j<indice;j++){
            strcpy(messaggio.string,M[i]);
            strcpy(messaggio.string2,M[j]);
            messaggio.mtype=C;
            if(msgsnd(coda,&messaggio,sizeof(messaggio)-sizeof(long),0)==-1){
                perror("errore invio ");
                exit(1);
            }

            if(msgrcv(coda,&ricevuto,sizeof(ricevuto)-sizeof(long),S,0)==-1){
                perror("errore ricezione");
                exit(1);
            }
            if(ricevuto.risultato == 1){
                strcpy(tmp,M[i]);
                strcpy(M[i],M[j]);
                strcpy(M[j],tmp);
            } 
            
        }
        //printf("%s \n ",M[i]);
    }
    strcpy(messaggio.string,"@@@");
    if(msgsnd(coda,&messaggio,sizeof(messaggio)-sizeof(long),0)==-1){
        perror("errore invio ");
        exit(1);
    }
}
void Compare(int coda){
    msg ricevuto;
    msg invio;
    while(1){
        if(msgrcv(coda,&ricevuto,sizeof(ricevuto)-sizeof(long),C,0)==-1){
            perror("errore nella ricezione");
            exit(1);
        }
        if(strcmp(ricevuto.string,"@@@")==0) exit(0);
        if(strcasecmp(ricevuto.string,ricevuto.string2)>0){
            invio.risultato=1;
        }
        else invio.risultato=2;
        invio.mtype=S;
        if(msgsnd(coda,&invio,sizeof(invio)-sizeof(long),0)==-1){
            perror("errore nella ricezione 2");
            exit(1);
        }
    }
}
int main(int argc,char* argv[]){
    if(argc<1){
        perror("argomenti non validi");
        exit(1);
    }
    msg messaggio;
    int coda;
    int pipefd[2]; //0 lettura 1 scrittura
    coda=msgget(IPC_PRIVATE,IPC_CREAT |0660 |IPC_EXCL);
    int numero_righe = 0;
    FILE* in;
    char buffer[MAX_LEN];
    in=fopen(argv[1],"r");
    while(fgets(buffer,MAX_LEN,in)!=NULL){
        numero_righe ++;

    }
    fclose(in);
    char M[numero_righe][MAX_LEN];
    for(int i=0;i<numero_righe;i++){
        for(int j=0;j<MAX_LEN;j++){
            M[i][j]=0;
        }
    }
    if(pipe(pipefd)==-1){
        perror("creazione pipe");
        exit(1);
    }
    if(!fork()){
        close(pipefd[0]);
        Sorter(coda,argv[1],M, numero_righe);
    
    }
    if(!fork()) Compare(coda);
    close(pipefd[1]);
    for (int i=0;i<numero_righe;i++){
        printf(" %s ",M[i]);
    }

}