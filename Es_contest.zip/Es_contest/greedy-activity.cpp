#include <iostream>
#include <fstream>
#include <typeinfo>
#include <cstring>
#include <sstream>

using namespace std;

class Activity {
public:
    int s; 
    int f;
    Activity(int s, int f) {
        this->s=s;
        this->f=f;
    }
};

void sort(Activity** array, int n) {
    for(int i=0; i<n-1; i++) {
        for(int j=i+1; j<n; j++) {
            if(array[j]->f<array[i]->f) swap(array[i],array[j]); 
        }
    }
}

void select_activity(Activity** array, int n, ofstream& output) {
    sort(array,n);
    int counter=1;
    int k=0;
    for(int i=1; i<n; i++) {
        if(array[i]->s>=array[k]->f) {
            counter++;
            k=i;
        }
    }
    output << counter << endl;
} 

int main() {
    ifstream input;
    ofstream output;
    input.open("input.txt");
    output.open("output.txt");
    for(int task=0; task<100; task++) {
        int n;
        input >> n;
        Activity** array=new Activity*[n];
        for(int i=0; i<n; i++) {
            char cIgnore;
            input >> cIgnore;
            int s; 
            input >> s;
            int f;
            input >> f;
            input >> cIgnore;
            array[i]=new Activity(s,f);
        }
        select_activity(array,n,output);
        for(int i=0; i<n; i++) delete array[i];
        delete[] array;
    }
}