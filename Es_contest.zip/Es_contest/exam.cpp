#include <iostream>
#include <fstream>
#include <typeinfo>
#include <cstring>
#include<cctype>
#define R 1
#define B 2
using namespace std;

template<class H> struct Nodo{
    Nodo<H>* padre;
    Nodo<H>* left;
    Nodo<H>* right;
    int  colore;
    H val;
};
template<class H>class  RB{
    public :
        Nodo<H>* radice;
        RB(){
            radice=NULL;
        }
        Nodo<H>* _find(H val){
            Nodo<H>* p=radice;
            while(p!=NULL && p->val!=val){
                if(val>p->val) p=p->right;
                else p=p->left;
            }
            return p;
        }
        void trapianta(Nodo<H>* u,Nodo<H>* v){
            if(u->padre==NULL) radice=v;
            else if(u->padre->left==u) u->padre->left=v;
            else u->padre->right=u;
            if(v!=NULL) v->padre=u->padre;
        }
        void left_rotate(Nodo<H>* a){
            Nodo<H>* y=a->right;
            Nodo<H>* z=a->padre;
            if(y!=NULL){
                a->right=y->left;
                y->left=a;
                trapianta(a,y);
                y->padre=z;
                a->padre=y;
                if(a->right!=NULL) a->right->padre=a;
            }
        }
        
        void right_rotate(Nodo<H>* a){
            Nodo<H>* y=a->left;
            Nodo<H>* z=a->padre;
            if(y!=NULL){
                a->left=y->right;
                y->right=a;
                trapianta(a,y);
                y->padre=z;
                a->padre=y;
                if(a->left!=NULL) a->left->padre=a;
            }
        }
        void R_rotate(H val){
            Nodo<H>* tmp=_find(val);
            if(tmp!=NULL) right_rotate(tmp);
        }
        void L_rotate(H val){
            Nodo<H>* tmp=_find(val);
            if(tmp!=NULL) left_rotate(tmp);
        }
        int _altezza(Nodo<H>* a){
            if(a==NULL)return 0;
            int sin;
            int max;
            int des;
            sin=_altezza(a->left);
            des=_altezza(a->right);
            if(sin>des) max=sin;
            else max=des;
            return 1+max;
        }
        void calcolo(ofstream& output){
            int x=(_altezza(radice));
            output<<x<<endl;
        }
        void insert_fx_up(Nodo<H>* a){
            if(a->padre!=NULL && a->padre->colore==B)return;
            if(a==radice){
                a->colore=B;
                return;
            } 
            Nodo<H>* genitore=a->padre;
            Nodo<H>* nonno=genitore->padre;
            Nodo<H>* zio=NULL;
            if(nonno->left==genitore)zio=nonno->right;
            else zio=nonno->left;
            if(zio!=NULL && zio->colore==R){
                nonno->colore=R;
                zio->colore=B;
                genitore->colore=B;
                insert_fx_up(nonno);
                return;
            }
            if(genitore==nonno->left){
                if(a==genitore->right){
                    L_rotate(genitore->val);
                    genitore=a;
                    a=genitore->left;
                }
                R_rotate(nonno->val);
                nonno->colore=R;
                genitore->colore=B;
                return;
            }
            else{
                if(a==genitore->left){
                    R_rotate(genitore->val);
                    genitore=a;
                    a=genitore->left;
                }
                L_rotate(nonno->val);
                nonno->colore=B;
                genitore->colore=R;
                return;
            }
        }
        void insert(H val){
            Nodo<H>* nuovo=new Nodo<H>;
            nuovo->val=val;
            nuovo->padre=nuovo->left=nuovo->right;
            Nodo<H>* y;
            Nodo<H>* p=radice;
            while(p!=NULL){
                y=p;
                if(val>p->val)p=p->right;
                else p=p->left;
            }
            nuovo->padre=y;
            if(val>y->val) y->right=nuovo;
            else y->left=nuovo;
            nuovo->colore=R;
            insert_fx_up(nuovo);
            
        }
        
};
template <class H> void parsing(ifstream& input,ofstream& output){
    cout<<"ma che paap"<<endl;
   // double numero=0;
    cout<<"prima";
    //input>>numero;
    RB<H>* alb=new RB<H>;

    H elem;
    for(int i=0;i<10;i++){
        input>>elem;
        cout<<elem; 
        alb->insert(elem);
    }

    cout<<"ci sono"<<endl;
    alb->calcolo(output);
}
int main(){
    ifstream input;
    ofstream output;
    input.open("input.txt");
    output.open("output.txt");
    string tipo;
    for(int i=0;i<1;i++){
        input>>tipo;
        cout<<tipo;
        switch (tipo[0])
        {
        case 'i':
            parsing<int>(input,output);
            break;
         case 'd':
            parsing<double>(input,output);
            break;
        default:
            break;
        }
    }
    return 0;
}