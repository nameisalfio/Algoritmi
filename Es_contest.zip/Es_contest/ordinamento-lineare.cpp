#include <iostream>
#include <fstream>
#include <typeinfo>
#include <cstring>
#include <sstream>

using namespace std;

template <class H> void print(H* vett, int size, ofstream& output) {
    for(int i=0; i<size; i++) output << vett[i] << " ";
}

int find_max(int* vett, int n) {
    int max=vett[0];
    for(int i=1; i<n; i++) {
        if(vett[i]>max) max=vett[i];
    }
    return max;
}

int find_min(int* vett, int n) {
    int min=vett[0];
    for(int i=1; i<n; i++) {
        if(vett[i]<min) min=vett[i];
    }
    return min;
}

template <class H> H* counting_sort(H* vett, int n, ofstream& output) {
    int* A=new int[n];
    for(int i=0; i<n; i++) A[i]=(int)(vett[i]);
    int max=find_max(A,n);
    int min=find_min(A,n);
    int range=max-min+1;
    int *C=new int[range];
    for(int i=0; i<range; i++) C[i]=0;
    for(int i=0; i<n; i++) C[A[i]-min]++;
    for(int i=1; i<range; i++) C[i]+=C[i-1];
    H* B=new H[n];
    for(int i=n-1; i>=0; i--) {
        B[C[A[i]-min]-1]=A[i];
        C[A[i]-min]--;
    }
    print(C,range,output);
    delete[] C;
    return B;
}

double* counting_sort(double* vett, int n, ofstream& output) {
    int* A=new int[n];
    for(int i=0; i<n; i++) A[i]=(int)(vett[i]*10);
    int max=find_max(A,n);
    int min=find_min(A,n);
    int range=max-min+1;
    int *C=new int[range];
    for(int i=0; i<range; i++) C[i]=0;
    for(int i=0; i<n; i++) C[A[i]-min]++;
    for(int i=1; i<range; i++) C[i]+=C[i-1];
    double* B=new double[n];
    for(int i=n-1; i>=0; i--) {
        B[C[A[i]-min]-1]=A[i]/10.0;
        C[A[i]-min]--;
    }
    print(C,range,output);
    delete[] C;
    return B;
}

template <class H> void parsing(int n, ifstream& input, ofstream& output) {
    H* array=new H[n];
    for(int i=0; i<n; i++) input >> array[i];
    H* result=counting_sort(array,n,output);
    print(result,n,output);
}

int main() {
    ifstream input;
    ofstream output;
    input.open("input.txt");
    output.open("output.txt");
    string tipo;
    int n;
    for(int task=0; task<100; task++) {
        input >> tipo;
        input >> n;
        switch(tipo[0]) {
            case 'i':
                parsing<int>(n,input,output);
                break;
            case 'd':
                parsing<double>(n,input,output);
                break;
            case 'b':
                parsing<bool>(n,input,output);
                break;
            case 'c':
                parsing<char>(n,input,output);
                break;
        }
        output << endl;
    }
}
