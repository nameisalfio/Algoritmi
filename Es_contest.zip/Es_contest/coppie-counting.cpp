#include <iostream>
#include <fstream>
#include <typeinfo>
#include <cstring>
#include <sstream>

using namespace std;

void print(int* vett,int size,ofstream& output) {
    for(int i=0; i<size; i++) output << vett[i] << " ";
}

template <class H> class Coppia {
public:
    H elem1;
    H elem2;
    Coppia(H x, H y) {
        elem1=x;
        elem2=y;
    }

    friend ostream& operator<<(ostream& os, const Coppia& a) {
        return os << "(" << a.elem1 << " " << a.elem2 << ")"; 
    }
};

template <class H> void print_coppie(Coppia<H>** vett, int size, ofstream& output) {
    for(int i=0; i<size; i++) output << *vett[i] << " ";
}

int find_max(Coppia<int>** vett, int n) {
    int max=vett[0]->elem1;
    for(int i=1; i<n; i++) {
        if(vett[i]->elem1>max) max=vett[i]->elem1;
    }
    return max;
}

int find_min(Coppia<int>** vett, int n) {
    int min=vett[0]->elem1;
    for(int i=1; i<n; i++) {
        if(vett[i]->elem1<min) min=vett[i]->elem1;
    }
    return min;
}

Coppia<double>** counting_sort(Coppia<double>** vett, int n, ofstream& output) {
    Coppia<int>** A=new Coppia<int>*[n];
    for(int i=0; i<n; i++) A[i]=new Coppia<int>(int(vett[i]->elem1*10),int(vett[i]->elem2*10));
    int max=find_max(A,n);
    int min=find_min(A,n);
    int range=max-min+1;
    int *C=new int[range];
    for(int i=0; i<range; i++) C[i]=0;
    for(int i=0; i<n; i++) C[A[i]->elem1-min]++;
    for(int i=1; i<range; i++) C[i]+=C[i-1];
    Coppia<double>** B=new Coppia<double>*[n];
    for(int i=n-1; i>=0; i--) {
        B[C[A[i]->elem1-min]-1]=new Coppia<double>(double(A[i]->elem1/10.0),double(A[i]->elem2/10.0));
        C[A[i]->elem1-min]--;
    }
    print(C,range,output);
    delete[] C;
    return B;
} 

int main() {
    ifstream input;
    ofstream output;
    input.open("input.txt");
    output.open("output.txt");
    for(int task=0; task<100; task++) {
        int n;
        double first_elem;
        double second_elem;
        char cIgnore;
        input >> n;
        Coppia<double>** array=new Coppia<double>*[n];
        for(int i=0; i<n; i++) {
            input >> cIgnore;
            input >> first_elem;
            input >> second_elem;
            input >> cIgnore;
            array[i]=new Coppia<double>(first_elem,second_elem);
        }
        Coppia<double>** result=counting_sort(array,n,output);
        print_coppie(result,n,output);
        output << endl;
    }
}
