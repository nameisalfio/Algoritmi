#include <iostream>
#include <fstream>
#include <typeinfo>
#include <cstring>
#include <sstream>

using namespace std;

void print_lcs(int** c, string x, int n, string y, int m, ofstream& output) {
    int k=c[n][m];
    char result[k+1];
    result[k]='\0';
    int i=n;
    int j=m;
    while(i>0 && j>0) {
        if(x[i-1]==y[j-1]) {
            result[k-1]=x[i-1];
            k--;
            i--;
            j--;
        }
        else {
            if(c[i][j-1]>=c[i-1][j]) j--;
            else i--;
        }
    }
    output << result << endl;
}
void lcs_length(string x, int n, string y, int m, ofstream& output) {
    int** c=new int*[n+1];
    for(int i=0; i<n+1; i++) c[i]=new int[m+1];
    for(int i=0; i<n+1; i++) c[i][0]=0;
    for(int j=0; j<m+1; j++) c[0][j]=0;
    for(int i=1; i<n+1; i++) {
        for(int j=1; j<m+1; j++) {
            if(x[i-1]==y[j-1]) c[i][j]=c[i-1][j-1]+1;
            else c[i][j]=max(c[i-1][j],c[i][j-1]);
        }
    }
    print_lcs(c,x,n,y,m,output);
    for(int i=0; i<n+1; i++) delete[] c[i];
    delete[] c;
}

int main() {
    ifstream input;
    ofstream output;
    input.open("input.txt");
    output.open("output.txt");
    for(int task=0; task<100; task++) {
        int n;
        int m;
        string x;
        string y;
        input >> n; 
        input >> m;
        input >> x;
        input >> y;
        lcs_length(x,n,y,m,output);
    }
}