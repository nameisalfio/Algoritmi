#include <iostream>
#include <fstream>
#include <typeinfo>
#include <cstring>
#include <sstream>

using namespace std;

void print(int* vett,int size,ofstream& output) {
    for(int i=0; i<size; i++) output << vett[i] << " ";
}

void counting_sort(int* A, int n, ofstream& output) {
    int max=A[0];
    int min=A[0];
    for(int i=1; i<n; i++) {
        if(A[i]>max) max=A[i];
        else if(A[i]<min) min=A[i];
    }
    int range=max-min+1;
    int *C=new int[range];
    for(int i=0; i<range; i++) C[i]=0;
    for(int i=0; i<n; i++) C[A[i]-min]++;
    for(int i=1; i<range; i++) C[i]+=C[i-1];
    int *B=new int[n];
    for(int i=n-1; i>=0; i--) {
        B[C[A[i]-min]-1]=A[i];
        C[A[i]-min]--;
    }
    for(int i=0; i<n; i++) A[i]=B[i];
    print(C,range,output);
    delete[] C;
    delete[] B;
} 

int main() {
    ifstream input;
    ofstream output;
    input.open("input.txt");
    output.open("output.txt");
    for(int task=0; task<100; task++) {
        int n;
        input >> n;
        int* array=new int[n];
        for(int i=0; i<n; i++) input >> array[i];
        counting_sort(array,n,output);
        print(array,n,output);
        output << endl;
        delete[] array;
    }
}
