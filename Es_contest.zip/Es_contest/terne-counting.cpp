#include <iostream>
#include <fstream>
#include <typeinfo>
#include <cstring>
#include <sstream>

using namespace std;

void print(int* vett,int size,ofstream& output) {
    for(int i=0; i<size; i++) output << vett[i] << " ";
}

template <class H> class Terna {
public:
    H elem1;
    H elem2;
    H elem3;
    Terna(H x, H y, H z) {
        elem1=x;
        elem2=y;
        elem3=z;
    }

    friend ostream& operator<<(ostream& os, const Terna& a) {
        return os << "(" << a.elem1 << " " << a.elem2 << " " << a.elem3 << ")"; 
    }
};

template <class H> void print_terne(Terna<H>** vett, int size, ofstream& output) {
    for(int i=0; i<size; i++) output << *vett[i] << " ";
}

int find_max(Terna<int>** vett, int n) {
    int max=vett[0]->elem1;
    for(int i=1; i<n; i++) {
        if(vett[i]->elem1>max) max=vett[i]->elem1;
    }
    return max;
}

int find_min(Terna<int>** vett, int n) {
    int min=vett[0]->elem1;
    for(int i=1; i<n; i++) {
        if(vett[i]->elem1<min) min=vett[i]->elem1;
    }
    return min;
}

Terna<double>** counting_sort(Terna<double>** vett, int n, ofstream& output) {
    Terna<int>** A=new Terna<int>*[n];
    for(int i=0; i<n; i++) A[i]=new Terna<int>(int(vett[i]->elem1*10),int(vett[i]->elem2*10),int(vett[i]->elem3*10));
    int max=find_max(A,n);
    int min=find_min(A,n);
    int range=max-min+1;
    int *C=new int[range];
    for(int i=0; i<range; i++) C[i]=0;
    for(int i=0; i<n; i++) C[A[i]->elem1-min]++;
    for(int i=1; i<range; i++) C[i]+=C[i-1];
    Terna<double>** B=new Terna<double>*[n];
    for(int i=n-1; i>=0; i--) {
        B[C[A[i]->elem1-min]-1]=new Terna<double>(double(A[i]->elem1/10.0),double(A[i]->elem2/10.0),double(A[i]->elem3/10.0));
        C[A[i]->elem1-min]--;
    }
    print(C,range,output);
    delete[] C;
    return B;
} 

int main() {
    ifstream input;
    ofstream output;
    input.open("input.txt");
    output.open("output.txt");
    for(int task=0; task<100; task++) {
        int n;
        double first_elem;
        double second_elem;
        double third_elem;
        char cIgnore;
        input >> n;
        Terna<double>** array=new Terna<double>*[n];
        for(int i=0; i<n; i++) {
            input >> cIgnore;
            input >> first_elem;
            input >> second_elem;
            input >> third_elem;
            input >> cIgnore;
            array[i]=new Terna<double>(first_elem,second_elem,third_elem);
        }
        Terna<double>** result=counting_sort(array,n,output);
        print_terne(result,n,output);
        output << endl;
    }
}