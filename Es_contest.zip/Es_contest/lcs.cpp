#include <iostream>
#include <fstream>
#include <typeinfo>
#include <cstring>
#include <sstream>

using namespace std;

void lcs_length(string x, int n, string y, int m, ofstream& output) {
    int c[n+1][m+1];
    for(int i=0; i<n+1; i++) c[i][0]=0;
    for(int j=0; j<m+1; j++) c[0][j]=0;
    for(int i=1; i<n+1; i++) {
        for(int j=1; j<m+1; j++) {
            if(x[i-1]==y[j-1]) c[i][j]=c[i-1][j-1]+1;
            else c[i][j]=max(c[i-1][j],c[i][j-1]);
        }
    }
    output << c[n][m] << endl;
}

int main() {
    ifstream input;
    ofstream output;
    input.open("input.txt");
    output.open("output.txt");
    for(int task=0; task<100; task++) {
        int n;
        int m;
        string x;
        string y;
        input >> n; 
        input >> m;
        input >> x;
        input >> y;
        lcs_length(x,n,y,m,output);
    }
}