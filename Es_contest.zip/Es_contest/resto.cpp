#include <iostream>
#include <fstream>
#include <typeinfo>
#include <cstring>
#include <sstream>
#include <climits>

using namespace std;

int resto(int* array, int n, int r) {
    int resto[r+1];
    resto[0]=0;
    for(int i=1; i<r+1; i++) resto[i]=INT_MAX;
    for(int i=1; i<r+1; i++) {
        for(int j=0; j<n; j++) {
            if(array[j]<=i) {
                int sub_res=resto[i-array[j]];
                if(resto[i-array[j]]!=INT_MAX && (resto[i-array[j]]+1)<resto[i]) 
                    resto[i]=(resto[i-array[j]])+1;
            }
        }
    }
    return resto[r];
}

int main() {
    ifstream input;
    ofstream output;
    input.open("input.txt");
    output.open("output.txt");
    for(int task=0; task<100; task++) {
        int r;
        int n;
        input >> r;
        input >> n;
        int* array=new int[n];
        for(int i=0; i<n; i++) input >> array[i];
        output << resto(array,n,r) << endl;


    }
}