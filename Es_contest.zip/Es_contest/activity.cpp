#include <iostream>
#include <fstream>
#include <typeinfo>
#include <cstring>
#include <sstream>

using namespace std;

class Activity {
public:
    int s; 
    int f;
    Activity(int s, int f) {
        this->s=s;
        this->f=f;
    }
};

void sort(Activity** array, int n) {
    for(int i=0; i<n-1; i++) {
        for(int j=i+1; j<n; j++) {
            if(array[j]->f<array[i]->f) swap(array[i],array[j]); 
            else if(array[j]->f==array[i]->f && array[i]->s<array[j]->s) swap(array[i],array[j]); 
        }
    }
}

int last_considered(Activity** array, int i) {
    for(int j=i-1; j>=0; j--) {
        if(array[j]->f<=array[i]->s) return j;
    }
    return -1;
}

void select_activity(Activity** array, int n, ofstream& output) {
    sort(array,n);
    int tempo_impiegato[n];
    tempo_impiegato[0]=(array[0]->f)-(array[0]->s);
    for(int i=1; i<n; i++) {
        int tempo=(array[i]->f)-(array[i]->s);
        int l=last_considered(array,i);
        if(l!=-1) tempo+=tempo_impiegato[l];
        if(tempo>tempo_impiegato[i-1]) tempo_impiegato[i]=tempo;
        else tempo_impiegato[i]=tempo_impiegato[i-1];
    }
    output << tempo_impiegato[n-1] << endl;
}

int main() {
    ifstream input;
    ofstream output;
    input.open("input.txt");
    output.open("output.txt");
    for(int task=0; task<100; task++) {
        int n;
        input >> n;
        Activity** array=new Activity*[n];
        for(int i=0; i<n; i++) {
            char cIgnore;
            input >> cIgnore;
            int s; 
            input >> s;
            int f;
            input >> f;
            input >> cIgnore;
            array[i]=new Activity(s,f);
        }
        select_activity(array,n,output);
        for(int i=0; i<n; i++) delete array[i];
        delete[] array;
    }
}