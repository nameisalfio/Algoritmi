#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/mman.h>
#include <dirent.h>
#include <sys/stat.h>
#include <fcntl.h>
#define MAX_LEN 1024
#define STOP 101
#define CONTINUE 100
#define P 1
typedef struct{
    long mtype;
    int risultato;
    int comando;
    char file[MAX_LEN];
    char carattere[1];
}msg;

void directory(int coda,char* dir,int id){
    msg ricevuto;
    msg invio;
    struct stat statbuff;
    while(1){
        if(msgrcv(coda,&ricevuto,sizeof(ricevuto)-sizeof(long),id,0)==-1){
            perror("errore nella riceione");
        }
        if(ricevuto.comando==1){
            DIR* in;
            in=opendir(dir);
            chdir(dir);
            int count = 0;
            struct dirent* entry;
            while((entry=readdir(in))!=NULL){
                lstat(entry->d_name,&statbuff);
                if(S_ISREG(statbuff.st_mode)){
                    count++;
                }
            }
            invio.risultato=count;
            invio.mtype=P;
            if(msgsnd(coda,&invio,sizeof(invio)-sizeof(long),0)==-1){
                perror("errore invio msg ");
                exit(1);
            }
            chdir("..");
            closedir(in);

        }
        else if(ricevuto.comando==2){
            DIR* in;
            in=opendir(dir);
            chdir(dir);
            int tot = 0;
            struct dirent* entry;
            while((entry=readdir(in))!=NULL){
                lstat(entry->d_name,&statbuff);
                if(S_ISREG(statbuff.st_mode)){
                    tot+=statbuff.st_size;
                }
            }
            invio.risultato=tot;
            invio.mtype=P;
            if(msgsnd(coda,&invio,sizeof(invio)-sizeof(long),0)==-1){
                perror("errore invio msg ");
                exit(1);
            }
            closedir(in);
            
        }
        else if(ricevuto.comando==3){
            char* f;
            int fd;
            int callo = 0;
            char testo[MAX_LEN];
            invio.mtype=P;
            DIR* in;
            in=opendir(dir);
            chdir(dir);
            struct dirent* entry;
            while((entry=readdir(in))!=NULL){
                memset(&testo,MAX_LEN,0);
                lstat(entry->d_name,&statbuff);
                if(S_ISREG(statbuff.st_mode) && strcmp(entry->d_name,ricevuto.file)==0){
                    strcpy(testo,entry->d_name);
                    break;
                }
                
            }
            chdir(dir);
            if((fd=open(testo,O_RDONLY))==-1){
                perror("mappatura file 1");
                    exit(1);
            }
            if((f=(char*)mmap(NULL,statbuff.st_size,PROT_READ,MAP_SHARED,fd,0))==MAP_FAILED){
                perror("MAP FILE 2");
                exit(1);
            }
            char ca=ricevuto.carattere[0];
            printf("ca %c \n",ca);
            printf("sono io  %d \n",statbuff.st_size);
            for(int i=0;i<statbuff.st_size;i++){
                printf("  %c e %c ",f[i],ca);
                if(f[i]==ca) {
                    callo += 1;
                }
            }
            invio.risultato=callo;
            invio.mtype=P;
            printf("sono callo %d \n",invio.risultato);
            if(msgsnd(coda,&invio,sizeof(invio)-sizeof(long),0)==-1){
                perror("mmm msg");
                exit(1);
            }
        }
    }
    exit(0);


}

int main(int argc,char* argv[]){
    if(argc<1){
        perror("argomenti non validi");
        exit(1);
    }
    int coda;
    char buffer[MAX_LEN];
    char* s;
    int dir = 0;
    msg invio; 
    msg  ricevuto;
    coda=msgget(IPC_PRIVATE,IPC_CREAT | 0660| IPC_EXCL);
    for(int i=1;i<argc;i++){
        if(!fork()) directory(coda,argv[i],i+1);
    }
    while(1){
        fgets(buffer,MAX_LEN,stdin);
        buffer[strcspn(buffer,"\n")]=0;
        s=strtok(buffer," ");
        if(strcmp(s,"num-files")==0){
            dir=atoi(strtok(NULL," "));
            invio.comando=1;
            invio.mtype=dir+1;
            if(msgsnd(coda,&invio,sizeof(invio)-sizeof(long),0)==-1){
                perror("errore invio msg p to f");
                exit(1);
            }
            if(msgrcv(coda,&invio,sizeof(invio)-sizeof(long),P,0)==-1){
                perror("errore nella ricezione msg to f");
                exit(1);
            }
            printf("%d \n",invio.risultato);
        }
        else if(strcmp(s,"total-size")==0){
            dir=atoi(strtok(NULL," "));
            invio.comando=2;
            invio.mtype=dir+1;
            if(msgsnd(coda,&invio,sizeof(invio)-sizeof(long),0)==-1){
                perror("errore invio msg p to f");
                exit(1);
            }
            if(msgrcv(coda,&invio,sizeof(invio)-sizeof(long),P,0)==-1){
                perror("errore nella ricezione msg to f");
                exit(1);
            }
            printf("%d \n",invio.risultato);
        }
        else if(strcmp(s,"sea")==0){
            dir=atoi(strtok(NULL," "));
            printf("ento nel else\n");
            strcpy(invio.file,strtok(NULL," "));
            strcpy(invio.carattere,strtok(NULL," "));
            printf("carattere %s ",invio.carattere);    
            invio.comando=3;
            invio.mtype=dir+1;
            if(msgsnd(coda,&invio,sizeof(invio)-sizeof(long),0)==-1){
                perror("errore invio msg p to f");
                exit(1);
            }
            if(msgrcv(coda,&ricevuto,sizeof(ricevuto)-sizeof(long),P,0)==-1){
                perror("errore nella ricezione msg to f");
                exit(1);
            }
            printf("callo ricevuto %d \n",ricevuto.risultato);
        }
    }
    return 0;
}