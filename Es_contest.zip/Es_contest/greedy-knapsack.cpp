#include <iostream>
#include <fstream>
#include <typeinfo>
#include <cstring>
#include <sstream>
#include <vector>
#include <algorithm>

using namespace std;

// Knapsack problem semplificato perchè ogni oggetto ha peso unitario (non abbiamo alcun bisogno di usare la programmazione dinamica)
void knapsack(vector<int> vett, int pesomax, ofstream& output) {
    int sum=0;
    sort(vett.begin(),vett.end(),greater<int>());
    for(int i=0; i<pesomax; i++) sum+=vett[i];
    output << sum << endl;
}

int main() {
    ifstream input;
    ofstream output;
    input.open("input.txt");
    output.open("output.txt");
    int n;
    int pesomax;
    int elem;
    for(int task=0; task<100; task++) {
        input >> n;
        input >> pesomax;
        vector<int> vett;
        for(int i=0; i<n; i++) {
            input >> elem;
            vett.push_back(elem);
        }
        knapsack(vett,pesomax,output);
    } 
}