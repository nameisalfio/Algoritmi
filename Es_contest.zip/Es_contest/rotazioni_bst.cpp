#include<iostream>
#include<fstream>
#include<cstring>
#include<cctype>

using namespace std;

template <class H> struct Nodo {
    H val;
    Nodo<H>* left;
    Nodo<H>* right;
    Nodo<H>* padre;
};

template <class H> class Albero {
public:
    Albero() {radice=NULL;}
    void insert(H elem);
    void inorder(ofstream& output);
    void preorder(ofstream& output);
    void postorder(ofstream& output);
    void trapianta(Nodo<H>* u, Nodo<H>* v);
    void cancella(H elem);
    Nodo<H>* find(H elem);
    Nodo<H>* minimo(Nodo<H>* x);
    void left_rotate(H elem);
    void right_rotate(H elem);
    
private:
    Nodo<H>* radice;
    
    void _inorder(Nodo<H>* x,ofstream& output) {
        if(x!=NULL) {
            _inorder(x->left,output);
            output << x->val << " ";
            _inorder(x->right,output);
        }
    }

    void _preorder(Nodo<H>* x,ofstream& output) {
        if(x!=NULL) {
            output << x->val << " ";
            _preorder(x->left,output);
            _preorder(x->right,output);
        }
    }

    void _postorder(Nodo<H>* x,ofstream& output) {
        if(x!=NULL) {
            _postorder(x->left,output);
            _postorder(x->right,output);
            output << x->val << " ";
        }
    }

    void _left_rotate(Nodo<H>* x) {
        Nodo<H>* y=x->right;
        Nodo<H>* z=x->padre;
        if(y!=NULL) {
            x->right=y->left;
            y->left=x;
            trapianta(x,y);
            y->padre=z;
            x->padre=y;
            if(x->right!=NULL) x->right->padre=x;
        }
    }

    void _right_rotate(Nodo<H>* x) {
        Nodo<H>* y=x->left;
        Nodo<H>* z=x->padre;
        if(y!=NULL) {
            x->left=y->right;
            y->right=x;
            trapianta(x,y);
            y->padre=z;
            x->padre=y;
            if(x->left!=NULL) x->left->padre=x;
        }
    }
};

template <class H> void Albero<H>::insert(H elem) {
    Nodo<H>* nuovo=new Nodo<H>;
    Nodo<H>* x=radice, *y=NULL;
    nuovo->val=elem;
    nuovo->left=nuovo->right=NULL;
    while(x!=NULL) {
        y=x;
        if(elem<=x->val) x=x->left;
        else x=x->right;
    }
    nuovo->padre=y;
    if(y==NULL) radice=nuovo;
    else if(elem<=y->val) y->left=nuovo;
    else y->right=nuovo;
}

template <class H> void Albero<H>::inorder(ofstream& output) {
    _inorder(radice,output);
    output << endl;
}

template <class H> void Albero<H>::preorder(ofstream& output) {
    _preorder(radice,output);
    output << endl;
}

template <class H> void Albero<H>::postorder(ofstream& output) {
    _postorder(radice,output);
    output << endl;
}

template <class H> void Albero<H>::left_rotate(H elem) {
    Nodo<H>* tmp=find(elem);
    if(tmp!=NULL) _left_rotate(tmp);
}

template <class H> void Albero<H>::right_rotate(H elem) {
    Nodo<H>* tmp=find(elem);
    if(tmp!=NULL) _right_rotate(tmp);
}

template <class H> void Albero<H>::trapianta(Nodo<H>* u, Nodo<H>* v) {
    if(u->padre==NULL) radice=v;
    else if(u==u->padre->left) u->padre->left=v;
    else u->padre->right=v;
    if(v!=NULL) v->padre=u->padre;
}

template <class H> void Albero<H>::cancella(H elem) {
    Nodo<H>* z=find(elem);
    if(z!=NULL) {
        Nodo<H>* y;
        if(z->left==NULL) trapianta(z,z->right);
        else if(z->right==NULL) trapianta(z,z->left);
        else {
            y=minimo(z->right);
            if(y->padre!=z) {
                trapianta(y,y->right);
                y->right=z->right;
                y->right->padre=y;
            }
            trapianta(z,y);
            y->left=z->left;
            y->left->padre=y;
        }
        delete z;
    }
}

template <class H> Nodo<H>* Albero<H>::find(H elem) {
    Nodo<H>* iter=radice;
    while(iter!=NULL && iter->val!=elem) {
        if(elem<=iter->val) iter=iter->left;
        else iter=iter->right;
    }
    return iter;
}

template <class H> Nodo<H>* Albero<H>::minimo(Nodo<H>* x) {
    Nodo<H>* iter=x;
    while(iter->left!=NULL)
        iter=iter->left;
    return iter;
}



template <class H> void parsing(ifstream& input,ofstream& output) {
    Albero<H>* tree=new Albero<H>;
    string strvisit;
    int n;
    int m;
    char optype;
    char cIgnore;
    char rotation_type;
    H elem;
    input >> n;
    input >> m;
    input >> strvisit;
    for(int i=0; i<n; i++) {
        input >> optype;
        input >> cIgnore;
        input >> cIgnore;
        input >> cIgnore;
        switch(optype) {
            case 'i':
                input >> elem;
                tree->insert(elem);
                break;
            case 'c':
                input >> cIgnore;
                input >> elem;
                tree->cancella(elem);
                break;
        }
    }
    for(int i=0; i<m; i++) {
        input >> rotation_type;
        switch(rotation_type) {
            case 'r':
                input >> cIgnore;
                input >> cIgnore;
                input >> cIgnore;
                input >> cIgnore;
                input >> cIgnore;
                input >> elem;
                tree->right_rotate(elem);
                break;
            case 'l':
                input >> cIgnore;
                input >> cIgnore;
                input >> cIgnore;
                input >> cIgnore;
                input >> elem;
                tree->left_rotate(elem);
                break;
        }
    }
    switch (strvisit[1]) {
        case 'r':
            tree->preorder(output);
            break;
        case 'n':
            tree->inorder(output);
            break;
        case 'o':
            tree->postorder(output);
            break;
    }
}

int main() {
    ifstream input;
    ofstream output;
    input.open("input.txt");
    output.open("output.txt");
    string tipo;
    for(int task=0; task<100; task++) {
        input >> tipo;
        switch (tipo[0]) {
            case 'i':
                parsing<int>(input,output);
                break;
            case 'c':
                parsing<char>(input,output);
                break;
            case 'd':
                parsing<double>(input,output);
                break;
            case 'b':
                parsing<bool>(input,output);
                break;
        }
    }
}


