#include <iostream>
#include <fstream>
#include <typeinfo>
#include <cstring>
#include <sstream>

using namespace std;

template <class H> struct Nodo {
    H val;
    Nodo<H>* succ;
};

template <class H> class List {
public:
    List() {testa=NULL;}
    void insert(H elem);
    void conta_nodi(ofstream& output);
private:
    Nodo<H>* testa;
};

template <class H> void List<H>::insert(H elem) {
    Nodo<H>* nuovo=new Nodo<H>;
    nuovo->val=elem;
    if(testa==NULL) {
        nuovo->succ=NULL;
        testa=nuovo;
    }
    else {
        nuovo->succ=testa;
        testa=nuovo;
    }
}

template <class H> void List<H>::conta_nodi(ofstream& output) {
    int num_nodi=0;
    if(testa==NULL) {
        output << num_nodi << " ";
    }
    else {
        Nodo<H>* iter=testa;
        while(iter!=NULL) {
            num_nodi++;
            iter=iter->succ;
        }
        output << num_nodi << " ";
    }
}

template <class H> class HashTable {
public:
    int m; // numero di slot della tabella
    int n; // numero elementi
    List<H>** arraylist;
    
    HashTable(int num_slot) {
        arraylist=new List<H>*[num_slot];
        for(int i=0; i<num_slot; i++) arraylist[i]=new List<H>();
        n=0;
        m=num_slot;
    }

    int div_hash(H elem) { // funzione hash: metodo della divisione
        int pos=((int)elem % m);
        return pos;
    }
};

template <class H> void parsing(int n,int m,ifstream& input,ofstream& output) {
    HashTable<H>* T=new HashTable<H>(m);
    H elem;
    int position=0;
    for(int i=0; i<n; i++) {
        input >> elem;
        position=T->div_hash(elem);
        T->arraylist[position]->insert(elem);
    }
    for(int i=0; i<m; i++) T->arraylist[i]->conta_nodi(output);
}

int main() {
    ifstream input;
    ofstream output;
    input.open("input.txt");
    output.open("output.txt");
    string tipo;
    int m;
    int n;
    for(int task=0; task<100; task++) {
        input >> tipo;
        input >> m;
        input >> n;
        switch(tipo[0]) {
            case 'i':
                parsing<int>(n,m,input,output);
                break;
            case 'd':
                parsing<double>(n,m,input,output);
                break;
            case 'b':
                parsing<bool>(n,m,input,output);
                break;
            case 'c':
                parsing<char>(n,m,input,output);
                break;
        }
        output << endl;
    }
}