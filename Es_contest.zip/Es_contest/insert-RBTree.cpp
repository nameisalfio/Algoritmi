#include<iostream>
#include<fstream>
#include<cstring>
#include<cctype>

#define B 0
#define R 1

using namespace std;

template <class H> struct Nodo {
    H val;
    Nodo<H>* left;
    Nodo<H>* right;
    Nodo<H>* padre;
    bool colore;
};

template <class H> class RBtree {
public:
    RBtree() {radice=NULL;}
    void insert_fixup(Nodo<H>* x);
    void insert(H elem);
    Nodo<H>* find(H elem);
    void inorder(ofstream& output);
    void preorder(ofstream& output);
    void postorder(ofstream& output);
    void left_rotate(H elem);
    void right_rotate(H elem);
    void trapianta(Nodo<H>* u, Nodo<H>* v);
private:
    Nodo<H>* radice;
    
    void _inorder(Nodo<H>* x,ofstream& output) {
        if(x!=NULL) {
            _inorder(x->left,output);
            output << "(" << x->val << " ";
            if(x->colore==B) output << "B) ";
            else output << "R) ";
            _inorder(x->right,output);
        }
    }

    void _preorder(Nodo<H>* x,ofstream& output) {
        if(x!=NULL) {
            output << "(" << x->val << " ";
            if(x->colore==B) output << "B) ";
            else output << "R) ";
            _preorder(x->left,output);
            _preorder(x->right,output);
        }
    }

    void _postorder(Nodo<H>* x,ofstream& output) {
        if(x!=NULL) {
            _postorder(x->left,output);
            _postorder(x->right,output);
            output << "(" << x->val << " ";
            if(x->colore==B) output << "B) ";
            else output << "R) ";
        }
    }

    void _left_rotate(Nodo<H>* x) {
        Nodo<H>* y=x->right;
        Nodo<H>* z=x->padre;
        if(y!=NULL) {
            x->right=y->left;
            y->left=x;
            trapianta(x,y);
            y->padre=z;
            x->padre=y;
            if(x->right!=NULL) x->right->padre=x;
        }
    }

    void _right_rotate(Nodo<H>* x) {
        Nodo<H>* y=x->left;
        Nodo<H>* z=x->padre;
        if(y!=NULL) {
            x->left=y->right;
            y->right=x;
            trapianta(x,y);
            y->padre=z;
            x->padre=y;
            if(x->left!=NULL) x->left->padre=x;
        }
    }
};

template <class H> void RBtree<H>::insert_fixup(Nodo<H>* x) {
    if(x->padre!=NULL && x->padre->colore==B) return;
    if(x==radice) {
        x->colore=B;
        return;
    }
    Nodo<H>* genitore=x->padre;
    Nodo<H>* nonno=genitore->padre;
    Nodo<H>* zio=NULL;
    if(genitore==nonno->right) zio=nonno->left;
    else zio=nonno->right;
    if(zio!=NULL && zio->colore==R) {
        // caso 1
        zio->colore=B;
        genitore->colore=B;
        nonno->colore=R;
        insert_fixup(nonno);
        return;
    }
    if(genitore==nonno->left) {
        if(x==genitore->right) {
            // caso 3 
            left_rotate(genitore->val);
            genitore=x;
            x=genitore->left;
        }
        // caso 2
        right_rotate(nonno->val);
        genitore->colore=B;
        nonno->colore=R;
        return;
    }
    else { // casi simmetrici
        if(x==genitore->left) {
            // caso 3 (simmetrico)
            right_rotate(genitore->val);
            genitore=x;
            x=genitore->right;
        }
        //caso 2 (simmetrico)
        left_rotate(nonno->val);
        genitore->colore=B;
        nonno->colore=R;
        return;
    }
}

template <class H> void RBtree<H>::insert(H elem) {
    Nodo<H>* nuovo=new Nodo<H>;
    Nodo<H>* x=radice, *y=NULL;
    nuovo->val=elem;
    nuovo->left=nuovo->right=NULL;
    while(x!=NULL) {
        y=x;
        if(elem<=x->val) x=x->left;
        else x=x->right;
    }
    nuovo->padre=y;
    if(y==NULL) radice=nuovo;
    else if(elem<=y->val) y->left=nuovo;
    else y->right=nuovo;
    nuovo->colore=R;
    insert_fixup(nuovo);
}

template <class H> Nodo<H>* RBtree<H>::find(H elem) {
    Nodo<H>* iter=radice;
    while(iter!=NULL && iter->val!=elem) {
        if(elem<=iter->val) iter=iter->left;
        else iter=iter->right;
    }
    return iter;
}

template <class H> void RBtree<H>::inorder(ofstream& output) {
    _inorder(radice,output);
    output << endl;
}

template <class H> void RBtree<H>::preorder(ofstream& output) {
    _preorder(radice,output);
    output << endl;
}

template <class H> void RBtree<H>::postorder(ofstream& output) {
    _postorder(radice,output);
    output << endl;
}

template <class H> void RBtree<H>::left_rotate(H elem) {
    Nodo<H>* tmp=find(elem);
    if(tmp!=NULL) _left_rotate(tmp);
}

template <class H> void RBtree<H>::right_rotate(H elem) {
    Nodo<H>* tmp=find(elem);
    if(tmp!=NULL) _right_rotate(tmp);
}

template <class H> void RBtree<H>::trapianta(Nodo<H>* u, Nodo<H>* v) {
    if(u->padre==NULL) radice=v;
    else if(u==u->padre->left) u->padre->left=v;
    else u->padre->right=v;
    if(v!=NULL) v->padre=u->padre;
}

template <class H> void parsing(ifstream& input,ofstream& output) {
    RBtree<H>* tree=new RBtree<H>;
    string strvisit;
    int n;
    H elem;
    input >> n;
    input >> strvisit;
    for(int i=0; i<n; i++) {
        input >> elem;
        tree->insert(elem);
    }
    switch (strvisit[1]) {
        case 'r':
            tree->preorder(output);
            break;
        case 'n':
            tree->inorder(output);
            break;
        case 'o':
            tree->postorder(output);
            break;
    }
}

int main() {
    ifstream input;
    ofstream output;
    input.open("input.txt");
    output.open("output.txt");
    for(int task=0; task<100; task++) {
        string tipo;
        input >> tipo;
        switch (tipo[0]) {
            case 'i':
                parsing<int>(input,output);
                break;
            case 'd':
                parsing<double>(input,output);
                break;
        }
    }
}