#include <iostream>
#include <fstream>
#include <typeinfo>
#include <cstring>
#include <sstream>

using namespace std;

void swap(int& a, int& b) {
    int tmp=b;
    b=a;
    a=tmp;
}

template <class H> class MinHeap {    
public:
    H* array;
    int size;
    int heapsize;
    int left(int i) {return i<<1;}
    int right(int i) {return (i<<1)|1;}
    int parent(int i) {return i>>1;}

    MinHeap(int len) {
        array=new H[len+1];
        size=len+1;
        heapsize=0;
    }

    void min_heapify(int i) {
        int l=left(i);
        int r=right(i);
        int min=i;
        if(l<=heapsize && array[l]>array[min]) min=l;
        if(r<=heapsize && array[r]>array[min]) min=r;
        if(min!=i) {
            swap(array[i],array[min]);
            min_heapify(min);
        }
    }

    void build_heap(int size) {
        heapsize=size;
        for(int i=heapsize/2; i>0; i--) min_heapify(i);
    }
    
    void print(ofstream& output) {
        for(int i=1; i<=heapsize; i++) output << array[i] << " ";
    }
};

template <class H> void parsing(int n,ifstream& input,ofstream& output) {
    MinHeap<H>* heap=new MinHeap<H>(n);
    H elem;
    for(int i=1; i<=n;i++) {
        input >> elem;
        heap->array[i]=elem;
    }
    heap->build_heap(n);
    heap->print(output);
}

int main() {
    ifstream input;
    ofstream output;
    input.open("input.txt");
    output.open("output.txt");
    string tipo;
    int n;
    for(int task=0; task<100; task++) {
        input >> tipo;
        input >> n;
        switch(tipo[0]) {
            case 'i':
                parsing<int>(n,input,output);
                break;
            case 'd':
                parsing<double>(n,input,output);
                break;
            case 'b':
                parsing<bool>(n,input,output);
                break;
            case 'c':
                parsing<char>(n,input,output);
                break;
        }
        output << endl;
    }
}
