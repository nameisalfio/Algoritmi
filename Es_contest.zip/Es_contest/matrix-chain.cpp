#include <iostream>
#include <fstream>
#include <typeinfo>
#include <cstring>
#include <sstream>
#include <climits>

using namespace std;

int num_parenthesizations(int* array, int n) {
    int matrix[n][n];
    for(int i=1; i<n; i++) matrix[i][i]=0;
    for(int d=2; d<n; d++) {
        for(int i=1; i<n-d+1; i++) {
            int j=d-1+i;
            matrix[i][j]=INT_MAX;
            for(int k=i; k<j; k++) {
                int q=matrix[i][k]+matrix[k+1][j]+array[i-1]*array[k]*array[j];
                if(q<matrix[i][j]) matrix[i][j]=q;
            }
        }
    }
    return matrix[1][n-1];
}
int main() {
    ifstream input;
    ofstream output;
    input.open("input.txt");
    output.open("output.txt");
    for(int task=0; task<100; task++) {
        int n;
        int rows, columns;
        char cIgnore;
        input >> n;
        int* array=new int[n+1];
        for(int i=0; i<n; i++) {
            input >> cIgnore;
            input >> rows;
            input >> cIgnore;
            input >> columns;
            input >> cIgnore;
            array[i]=rows;
        }
        array[n]=columns;
        output << num_parenthesizations(array,n+1);
        output << endl;
    }
}