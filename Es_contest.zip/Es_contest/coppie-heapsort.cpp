#include <iostream>
#include <fstream>
#include <typeinfo>
#include <cstring>
#include <sstream>

using namespace std;

void swap(int& a, int& b) {
    int tmp=b;
    b=a;
    a=tmp;
}

template <class H> class Coppia {
public:
    H elem1;
    H elem2;
    Coppia(H x, H y) {
        elem1=x;
        elem2=y;

    }

    friend bool operator>(Coppia& a, Coppia& b) {
        if(a.elem1>b.elem1) return 1;
        else if(a.elem1==b.elem1 && a.elem2>b.elem2) return 1;
        return 0;
    }

    friend ostream& operator<<(ostream& os, Coppia& a) {
        return os << "(" << a.elem1 << " " << a.elem2 << ")"; 
    }

};

template <class H> class MaxHeap {    
public:
    Coppia<H>** array;
    int size;
    int heapsize;
    int num_chiamate;
    int left(int i) {return i<<1;}
    int right(int i) {return (i<<1)|1;}
    int parent(int i) {return i>>1;}

    MaxHeap(int len) {
        array=new Coppia<H>*[len+1];
        size=len+1;
        heapsize=0;
        num_chiamate=0;
    }

    void max_heapify(int i) {
        int l=left(i);
        int r=right(i);
        int max=i;
        if(l<=heapsize && *array[l]>*array[max]) max=l;
        if(r<=heapsize && *array[r]>*array[max]) max=r;
        if(max!=i) {
            swap(array[i],array[max]);
            max_heapify(max);
        }
        if(heapsize>=1) num_chiamate++;
    }

    void build_heap(int size) {
        heapsize=size;
        for(int i=heapsize/2; i>0; i--) max_heapify(i);
    }

    void extract_max() {
        swap(array[1],array[heapsize]);
        heapsize--;
        max_heapify(1);
    }

    void heapsort() {
        int num_nodi=heapsize;
		for (int i=0; i<num_nodi; i++) extract_max();
        heapsize=num_nodi;
    }
    
    void print(ofstream& output) {
        heapsize=size-1;
        for(int i=1; i<=heapsize; i++) output << *array[i] << " ";
    }
};

template <class H> void parsing(int n,ifstream& input,ofstream& output) {
    MaxHeap<H>* heap=new MaxHeap<H>(n);
    H first_elem;
    H second_elem;
    char cIgnore;
    for(int i=1; i<=n;i++) {
        input >> cIgnore;
        input >> first_elem;
        input >> second_elem;
        input >> cIgnore;
        heap->array[i]=new Coppia<H>(first_elem,second_elem);
    }
    heap->build_heap(n);
    heap->heapsort();
    output << heap->num_chiamate << " ";
    heap->print(output);
}

int main() {
    ifstream input;
    ofstream output;
    input.open("input.txt");
    output.open("output.txt");
    string tipo;
    int n;
    for(int task=0; task<100; task++) {
        input >> tipo;
        input >> n;
        switch(tipo[0]) {
            case 'i':
                parsing<int>(n,input,output);
                break;
            case 'd':
                parsing<double>(n,input,output);
                break;
            case 'b':
                parsing<bool>(n,input,output);
                break;
            case 'c':
                parsing<char>(n,input,output);
                break;
        }
        output << endl;
    }
}